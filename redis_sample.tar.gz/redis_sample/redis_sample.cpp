#include <iostream>
#include <memory>
#include <vector>
#include <hiredis.h>

// 参考
// https://qiita.com/Ki4mTaria/items/d73cf3d244c903d493eb
// https://gist.github.com/tiijima/14152256264224862e93



class RedisConnection {

using RedisContextPtr = std::unique_ptr<redisContext, decltype(&redisFree)>;
using RedisReplyPtr = std::unique_ptr<redisReply, decltype(&freeReplyObject)>;

public : 
    RedisConnection(const std::string &hostname, int port) : 
        _raw(init(hostname, port)) {
    }

    void put(const std::string &key, const char *value, size_t size) {
        const std::string command = std::string("SET ") + key + " %b";
        exec_command(command, value, size);
    }

    template<typename T>
    void put(const std::string &key, const T &value) {
        put(key, reinterpret_cast<const char *>(&value), sizeof(value));
    }

    template<typename T>
    void put_all(const std::string &key, const T *values, size_t size) {
        put(key, 
            reinterpret_cast<const char *>(values), sizeof(T) * size);   
    }

    void get(const std::string &key, char *value, size_t size) {
        const std::string command = std::string("GET ") + key;
        auto reply = exec_command(command);
        std::copy(reply->str, reply->str + size, value);
    }

    template<typename T>
    T get(const std::string &key) {
        T value;
        get(key, reinterpret_cast<char *>(&value), sizeof(value));
        return value;
    }

    template<typename T>
    void get_all(const std::string &key, T *values, size_t size) {
        get(key, reinterpret_cast<char *>(values),
            sizeof(T) * size);
    }

private : 
    RedisContextPtr _raw;
    
    RedisContextPtr init(const std::string &hostname, int port) {
        auto conn = RedisContextPtr(
            redisConnect(hostname.c_str(), port),
            redisFree
        );
        throw_if_error();
        return conn;
    }

    void throw_if_error() {
        if (_raw && _raw->err) {
            throw std::runtime_error(
                std::string("redis error ") + std::to_string(_raw->err) + " : " + _raw->errstr
            );
        }
    }

    template<typename ...Args>
    RedisReplyPtr exec_command(const std::string &command, Args&& ...args) {
        auto reply = RedisReplyPtr(
            reinterpret_cast<redisReply*>(
                redisCommand(_raw.get(), command.c_str(), std::forward<Args>(args)...)
            ),
            freeReplyObject
        );
        if (!reply) {
            throw_if_error();
        }
        return reply;
    }


};


int test() {
    std::cout << "Hello World!" << std::endl;
    RedisConnection conn("127.0.0.1", 6379);
    {
        std::cout << "==== string value ====" << std::endl;
        const std::string key = "key1";
        const std::string value = "valuevalue";
        conn.put(key, value.data(), value.size());
        std::string ret(value.size(), '\0');
        conn.get(key, const_cast<char *>(ret.data()), ret.size());
        std::cout << ret << std::endl;
        std::cout << "======================" << std::endl;
    }
    {
        std::cout << "===== bin value  =====" << std::endl;
        const size_t size = 1024 * 1024 * 1024 - 1;
        const std::string key = "binkey1";
        const std::vector<uint8_t> value(size, 0);
        conn.put_all(key, value.data(), value.size());
        std::cout << "put ok." << std::endl;
        std::vector<uint8_t> ret(size, 0);
        conn.get_all(key, ret.data(), ret.size());
        std::cout << "======================" << std::endl;
    }
}

int main() {
    try {
        return test();
    } catch(const std::exception& e) {
        std::cerr << e.what() << std::endl;
        return 1;
    } catch(...) {
        return 1;
    }
}