Redisサンプル
====

Redisインストール
----

* CentOS7上にインストールする。
* CentOS のrpmリポジトリでは公開されてないので、EPELのサイトから入手する。

    ```
    yum install epel-release
    yum install redis
    ```
* RPMからインストールする場合、必要となるパッケージは以下の通り。

    ```
    jemalloc-3.6.0-1.el7.x86_64.rpm                                       redis-3.2.12-2.el7.x86_64.rpm  
    ```


Hiredis
----
* Redisのクライアントはいくつかあったが公式のもので推奨されているhiredisを選択する。

    https://redis.io/clients#c

* hiredisパッケージのインストール

    ```
    yum install hiredis hiredis-devel
    ```

Redisの起動
----

* redisを起動する

    ```sh
    systemctl start redis
    ```

