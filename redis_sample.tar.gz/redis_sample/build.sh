#!/bin/bash

rm -rf a.out*

g++ -g -O0 --std=c++11 \
    -I/usr/include/hiredis \
    -L/usr/lib64 \
    -lhiredis \
    redis_sample.cpp

./a.out 