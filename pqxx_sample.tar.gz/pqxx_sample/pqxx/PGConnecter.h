#pragma once
#include <string>
#include <sstream>
#include <memory>
#include <unordered_map>
#include <algorithm>
#include <libpq-fe.h>
#include <libpq/libpq-fs.h>

// 参考
// https://www.postgresql.jp/document/9.6/html/libpq-exec.html
// https://www.postgresql.jp/document/9.6/html/libpq-example.html

namespace {

template<typename T>
std::string to_string(const T& v) {
	std::stringstream ss;
	ss << v;
  return ss.str();
}

template<typename... Args>
std::vector<std::string> as_vector(Args... args) {
	return { to_string(args)... };
}


} // unnamed namespace

class PGResultSet {
    using PGResultSetPtr = std::unique_ptr<PGresult, decltype(&PQclear)>;

public :
    PGResultSet(PGresult *res) : _raw(
        PGResultSetPtr(res, PQclear)
    ) {
    }
    int get_record_length() {
        return PQntuples(_raw.get());
    }

    template<typename T>
    T get_value_as(int row, int col) {
        T val;
        std::istringstream ss(get_value(row, col));
        ss >> val;
        return val;
    }

    std::string get_value(int row, int col) {
        return std::string(PQgetvalue(_raw.get(), row, col));
    }

    bool is_null(int row, int col) {
        return PQgetisnull(_raw.get(), row, col) == 1;
    }

    bool is_error() {
        switch(get_result_status()) {
            case PGRES_EMPTY_QUERY :
            case PGRES_COMMAND_OK : 
            case PGRES_TUPLES_OK :
                return false;
            default : {
                return true;
            }
        }
    }

private :
    PGResultSetPtr _raw;

    ExecStatusType get_result_status() {
        return PQresultStatus(_raw.get());
    }
};

class PGConnecter {
    
    using PGconnPtr = std::unique_ptr<PGconn, decltype(&PQfinish)>;
public : 

    PGConnecter(const std::string &conn_info) : _raw(
        PGconnPtr(PQconnectdb(conn_info.c_str()), PQfinish)
    ) {
        if (PQstatus(_raw.get()) != CONNECTION_OK) {
            throw std::runtime_error("connection faild.");
        }
        // std::cout << "connection success." << std::endl;
    }

    template<typename... Args>
    std::shared_ptr<PGResultSet> execute(const std::string &sql, Args ...args) {
        const auto params = as_vector(args...);
        std::vector<const char *> cstr_params;
        for (const auto& s : params) {
            cstr_params.emplace_back(s.data());
        }
        auto res = std::make_shared<PGResultSet>(
            // PQexec(_raw.get(), sql.c_str())
            PQexecParams(
                _raw.get(),
                sql.c_str(),
                cstr_params.size(),
                nullptr,        /* バックエンドにパラメータの型を推測させる。 */
                cstr_params.data(),
                nullptr,        /* テキストのため、パラメータ長は不要。 */
                nullptr,        /* デフォルトですべてのパラメータはテキスト。 */
                0               /* テキスト結果を要求。 */
            )          
        );
        if (res->is_error()) {
            throw std::runtime_error("sql error. " + get_error_message());  
        }
        return res;
    }

    void begin() {
        execute("BEGIN");
    }

    void commit() {
        execute("COMMIT");
    }

    void rollback() {
        execute("ROLLBACK");
    }

    PGconn* get_raw() {
        return _raw.get();
    }
private :
    PGconnPtr _raw;
    std::string get_error_message() {
        return std::string(PQerrorMessage(_raw.get()));
    }
};

