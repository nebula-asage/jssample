#!/bin/bash

PGSQL_DIR=/usr/pgsql-9.6

SCRIPT_DIR=$(cd $(dirname $0); pwd)

# clean
rm -rf *.dSYM main

# build
g++ -g -time -std=c++11 -O0 \
    -I${SCRIPT_DIR}/pqxx \
    -I${PGSQL_DIR}/include \
    -L${PGSQL_DIR}/lib \
    -lpq main.cpp -o main