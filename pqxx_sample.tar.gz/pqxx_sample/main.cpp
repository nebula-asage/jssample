#include <iostream>
#include <PGConnecter.h>

int main(int argn, char* argc[]) {
    std::cout << "Hello World!" << std::endl;
    const std::string kConnInfo = "postgresql://postgres@localhost:5432/postgres";
    
    try {
        auto conn = std::make_shared<PGConnecter>(kConnInfo);
        {
            auto res = conn->execute("select 1111, $1::bigint", 100);
            std::cout << res->get_value_as<uint64_t>(0, 0) << std::endl;
            std::cout << res->get_value_as<std::string>(0, 1) << std::endl;
        }
    } catch (const std::exception& e) {
        std::cerr << e.what() << std::endl;
        return 1;
    }
    return 0;
}