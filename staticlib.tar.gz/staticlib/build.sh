#!/bin/bash

set -eu

rm -rf a.out* *.o *.a

g++ -g -O0 --std=c++11 -c -o staticlib.o staticlib.cpp
ar cqT libstaticlib.a staticlib.o 

g++ -g -O0 --std=c++11 -c -o main.o  main.cpp
g++ main.o libstaticlib.a -o a.out
#g++ main.o staticlib.o -o a.out

#g++ -g -O0 --std=c++11 main.cpp -o a.out

./a.out
