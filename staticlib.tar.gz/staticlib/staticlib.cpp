#include <iostream>
#include <vector>
#include "staticlib.h"

namespace {

std::vector<std::string>& get_vvvv() {
    static std::vector<std::string> vvvv;
    return vvvv;
}

} // namespace

void foo(const std::string &mes) {
    get_vvvv().emplace_back(mes);
}

void bar() {
    std::cout << "size : " << get_vvvv().size() << std::endl;
    for (auto && v : get_vvvv()) {
        std::cout << v << ",";
    }
    std::cout << std::endl;
}