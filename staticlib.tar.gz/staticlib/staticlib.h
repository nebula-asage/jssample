#pragma once

void foo(const std::string& mes);

void bar();

#define FOO(MES) namespace { \
        struct Foo { Foo() { foo(MES); } } st_foo; \
    }
