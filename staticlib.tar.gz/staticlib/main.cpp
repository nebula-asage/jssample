#include <iostream>

#include "staticlib.h"

FOO("abcdefg!")

int main() {

    std::cout << "Hello world !" << std::endl;

    bar();

    return 0;
}