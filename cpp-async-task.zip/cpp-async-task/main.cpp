#include <iostream>
#include <string>
#include <thread>
#include <functional>
#include <chrono>
#include <mutex>
#include <map>
#include <memory>
#include <sstream>

class AsyncTimer {

public :

    using Runnable = std::function<void()>;

    template<typename Duration>
    AsyncTimer(Duration duration, Runnable runnable) {

        _thread = std::thread([&]() {
            while(!_stopping) {
                runnable();
                std::this_thread::sleep_for(duration);
            }
        });
    }

    ~AsyncTimer() {
        // TODO shutdown
    }

private : 

    bool _stopping = false;
    std::thread _thread;


};

int64_t get_timestamp() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::system_clock::now().time_since_epoch()
            ).count();
}

std::size_t gen_hash_id(std::size_t seed) {
    return std::hash<unsigned long long>()(seed);
}

enum TaskStatus {
    // 未開始
    kTaskStatusNotStarted,
    // 実行中
    kTaskStatusExecuting,
    // 完了
    kTaskStatusCompleted,
    // 中断
    kTaskStatusCanncelled,
    // 失敗
    kTaskStatusFailed,
};

struct TaskView {
    std::string id;
    std::string name;
    TaskStatus status;

    // 未完了以外の数
    uint64_t progress_num;
    // Step 総数
    uint64_t total_num;

    // ステータスメッセージ
    std::string status_message;
};

struct Step;

// 永続化データ
struct ParsistenceData {

    // std::string だけど byte buffer

    std::string data;
    std::string share;
};

struct Task {
    std::string id;
    std::string name;
    TaskStatus status;
    uint64_t index;
    size_t next_hash_id;

    int64_t created_at;
    int64_t updated_at;

    std::vector<Step> steps;
    
    // 受付時データ
    ParsistenceData data_at_reception;

    // 完了時データ
    ParsistenceData data_at_completion;

    TaskView view() {
        return {id, name, status, 0, steps.size()};
    }
};

enum StepStatus {
    // 未完了
    kStepStatusNotCompleted,
    // 完了
    kStepStatusCompleted,
    // 失敗
    kStepStatusFailed,
};

class StepException : public std::runtime_error {
public :
    StepException(const std::string &id, const std::string &message) : std::runtime_error(message), _id(id), _message(message) {
    }

private :
    const std::string _id;
    const std::string _message;
};

struct Step {
    // 1からの連番. ソート用
    int64_t no;
    std::string id;
    // std::string name;

    size_t next_hash_id;
    StepStatus status;

    // 異常時のみ記録。サーバ間で異なる
    std::string message_id;
    std::string message_detail;
};

struct StepContext {
    Task task;
    Step step;

    // 実行途中の状態を保持するポインタ
    void* ptr;
};

using StepFunction = std::function<void(StepContext &step_context)>;

class TaskManager {
public :

    TaskManager(StepFunction step_function, uint64_t concurrency = 3) : 
        _step_function(step_function), _concurrency(concurrency), _next_hash_id(gen_hash_id(kSeed)), _counter(0), _stopping(false) {
        _monitor_thread = std::thread([&]() {
            while(!_stopping) {
                {
                    std::lock_guard<decltype(_mutex)> lock(_mutex);
                    std::cout << this->get_timestamp() << std::endl; 

                    // TODO list 

                    // TODO 実行中に更新
                }

                {
                    // TODO 別スレッドで実行

                    // → ステップ実行

                    {
                        std::lock_guard<decltype(_mutex)> lock(_mutex);
                        // TODO ステータスを完了 or 失敗に変更
                    }
                }
                std::this_thread::sleep_for(std::chrono::seconds(3));
            }
        });
    }

    ~TaskManager() {
        // TODO 安全に停止
    }

    void add(const std::string &name, size_t next_hash_id, int64_t timestamp, const std::vector<std::string> &step_ids) {
        std::lock_guard<decltype(_mutex)> lock(_mutex);
        const auto id = gen_id();
        
        auto task = std::make_shared<Task>(Task{id, name, TaskStatus::kTaskStatusNotStarted, _counter++, next_hash_id, timestamp, 0});
        for (int64_t i = 0; i < step_ids.size(); ++i) {
            task->steps.emplace_back(Step {
                i + 1, 
                step_ids.at(i), 
                // タスク追加時の hash_id + 連番で各ステップ用の hash_id を生成する。
                gen_hash_id(next_hash_id + i + 1), 
                // 未完了で初期化
                StepStatus::kStepStatusNotCompleted 
            });
        }

        _tasks.emplace(id, task);

        // TODO 受付時データをファイルに書き込む
    }

    // タスク一覧
    std::vector<TaskView> list() {
        std::lock_guard<decltype(_mutex)> lock(_mutex);
        std::vector<TaskView> tasks;
        for(auto && entry : _tasks) {
            tasks.emplace_back(entry.second->view());
        }
        return tasks;
    }

    // タスク結果を返す。
    TaskView get(const std::string &id) {
        std::lock_guard<decltype(_mutex)> lock(_mutex);
        return _tasks.at(id)->view();
    }

    void remove(const std::string &id) {
        std::lock_guard<decltype(_mutex)> lock(_mutex);
        _tasks.erase(id);
    }

private :
    const size_t kSeed = 0;

    StepFunction _step_function;

    // 同時実行数
    int _concurrency;

    // 監視用
    size_t _next_hash_id;

    uint64_t _counter;
    
    bool _stopping;

    // 監視スレッド
    std::thread _monitor_thread;
    
    // タスクリスト
    std::map<std::string, std::shared_ptr<Task>> _tasks;
    
    // サーバ間ロック
    std::mutex _mutex;

    std::string gen_id() {
        std::stringstream ss;
        ss << "task_" << _counter;
        return ss.str();
    }

    int64_t get_timestamp() {
        _next_hash_id = gen_hash_id(_next_hash_id);
        return ::get_timestamp();
    }

};

int main() {
    std::cout << "Hello world." << std::endl;
    // AsyncTimer timer(std::chrono::seconds(3), [&]() {
    //     std::cout << get_timestamp() << std::endl;
    // });
    TaskManager task_manager([](StepContext& context){

    });

    std::cout << "created." << std::endl;

    std::this_thread::sleep_for(std::chrono::hours(24));
}