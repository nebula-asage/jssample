#!/bin/bash 

g++ \
    --std=c++17 \
    -O0 \
    main.cpp \
    -I/usr/include 