#!/bin/bash

./build.sh

./a.out