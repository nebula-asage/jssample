#!/bin/bash

set -eu

SCRIPT_DIR=$(cd $(dirname $0); pwd)

make -j2 -C ${SCRIPT_DIR}