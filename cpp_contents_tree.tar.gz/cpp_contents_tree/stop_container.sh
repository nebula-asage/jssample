#!/bin/bash

set -eu

SCRIPT_DIR=$(cd $(dirname $0); pwd)

IMAGE_NAME=$(cd $(dirname $0);  basename $(pwd))
CONTAINER_NAME=${IMAGE_NAME}

if [ -n "$(docker ps -qa  -f name=${CONTAINER_NAME})" ]; then
    docker stop ${CONTAINER_NAME}
fi