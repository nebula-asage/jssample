#pragma once
#include "digest/MessageDigest.h"

namespace digest {

class Sha1Hash : public MessageDigest<20> {
public :
    Sha1Hash();
    ~Sha1Hash();
private :
    void *_ctx;
    void _initialize() override;
    void _update(const unsigned char *data, size_t size) override;
    void _finalize(unsigned char *digest) override;
};

} // namespace digest