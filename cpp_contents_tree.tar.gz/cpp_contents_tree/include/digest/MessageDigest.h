#pragma once
#include <array>

namespace digest {

template<size_t mes_size>
class MessageDigest {
public :

    using Digest = std::array<unsigned char, mes_size>;
    static constexpr const auto kSize = mes_size;
    virtual ~MessageDigest() = default;

    MessageDigest() : _is_initialized(false), _is_finalized(false) {
    }

    MessageDigest& update(const unsigned char *data, size_t size) {
        if (_is_finalized) {
            throw std::logic_error("already finalized error.");
        }
        if (!_is_initialized) {
            reset();
        }
        _update(data, size);
        return *this;
    }

    template<typename T>
    MessageDigest& update(const T *data, size_t size = 1) {
        // static_assert(sizeof(T) == sizeof(char), "T is not single byte type.");
        return update(
            reinterpret_cast<const unsigned char*>(data), 
            size * sizeof(T)
        );
    }

    const unsigned char* data() {
        return digest().data();
    }

    size_t size() const {
        return kSize;
    }

    const Digest &digest() {
        if (!_is_initialized) {
            reset();
        }
        if (!_is_finalized) {
            _finalize(_digest.data());
            _is_finalized = true;
        }
        return _digest;
    }

    void reset() {
        _digest.fill(0);
        _initialize();
        _is_initialized = true;
        _is_finalized = false;
    }
protected : 
    virtual void _initialize() = 0;
    virtual void _update(const unsigned char *data, size_t size) = 0;
    virtual void _finalize(unsigned char *digest) = 0;
private :
    bool _is_initialized;
    bool _is_finalized;
    Digest _digest;
};

} // namespace digest