#pragma once
#include "digest/MessageDigest.h"

namespace digest {

template<class MD>
class MessageDigestStream : public std::ostream {

    class MessageDigestBuffer : public std::streambuf {
    public :
        MessageDigestBuffer() {
            // バッファリングしない
            setbuf(0, 0);
        }
        MD& get_md() {
            return _md;
        }

    protected :

        // int_type overflow(int_type c = traits_type::eof()) override {
        //     // std::cout << "over : " << char(c) << std::endl;
        //     _md.update(reinterpret_cast<const unsigned char*>(&c), 1);
        //     return 0;
        // }

        // overflow より xsputn をオーバーライドしたほうがパフォーマンスが良い

        std::streamsize xsputn(const char_type* data, std::streamsize size) override {
            _md.update(reinterpret_cast<const unsigned char*>(data), size);
            return size;
        }

        int_type underflow(void) override {
            // nop
            return traits_type::eof();
        }
    private :
        MD _md;

    };


public : 
    MessageDigestStream() : std::ostream(&_buffer) {
    }

    const typename MD::Digest& digest() {
        return _buffer.get_md().digest();
    }

    void reset() {
        _buffer.get_md().reset();
    }
private :
    MessageDigestBuffer _buffer;
};


} // namespace digest