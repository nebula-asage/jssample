#pragma once

#include "digest/Sha1Hash.h"
#include "digest/MessageDigestStream.h"

namespace digest {

using Sha1HashStream = MessageDigestStream<Sha1Hash>;

} // namespace digest