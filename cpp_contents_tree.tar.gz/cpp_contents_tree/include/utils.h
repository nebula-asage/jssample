#pragma once

#include <vector>
#include <string>

std::string to_hex(const char* data, size_t size);

template<typename T>
std::string to_hex(const std::vector<T> &data) {
    return to_hex(
        reinterpret_cast<const char*>(data.data()),
        sizeof(T) * data.size()
    );
}


template<
    typename IntType, 
    typename std::enable_if<
            std::is_integral<IntType>::value, std::nullptr_t
        >::type = nullptr
    >
std::string to_hex(IntType value);