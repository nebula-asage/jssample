#!/bin/bash

set -eu

SCRIPT_DIR=$(cd $(dirname $0); pwd)

IMAGE_NAME=$(cd $(dirname $0);  basename $(pwd))
CONTAINER_NAME=${IMAGE_NAME}

if [ -n "$(docker ps -qa  -f name=${CONTAINER_NAME})" ]; then
    echo "${CONTAINER_NAME} is already running."
    exit 1
fi

echo -n "building... "
docker build \
    --quiet \
    --tag ${IMAGE_NAME} \
    ${SCRIPT_DIR}

echo -n "running... "
docker run \
    --name ${CONTAINER_NAME} \
    --rm \
    --detach \
    --volume $(pwd):/work \
    ${IMAGE_NAME} \
    tail -f /dev/null