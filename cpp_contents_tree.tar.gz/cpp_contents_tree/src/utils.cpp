#include <sstream>
#include <iomanip>

#include "utils.h"

std::string to_hex(const char* data, size_t size) {
    std::stringstream ss;
    for (size_t i = 0; i < size; ++i) {
        ss << to_hex(data[i]);
    }
    return ss.str();
}

template<
    typename IntType, 
    typename std::enable_if<
            std::is_integral<IntType>::value, std::nullptr_t
        >::type = nullptr
    >
std::string to_hex(IntType value) {
    // static_assert(std::is_integral<IntType>::value == true, "int type.");
    std::stringstream ss;
    ss << std::setfill('0') 
        << std::setw(sizeof(value) * 2) 
        << std::hex 
        << (sizeof(value) == sizeof(char) ? uint16_t(value) & 0xff : value);
    return ss.str();
}

// 明示的実体化
#define DEFINE_TO_HEX(T) \
template std::string to_hex(T value);

// DEFINE_TO_HEX(char)
// DEFINE_TO_HEX(unsigned char)
DEFINE_TO_HEX(int8_t)
DEFINE_TO_HEX(uint8_t)
DEFINE_TO_HEX(int16_t)
DEFINE_TO_HEX(uint16_t)
DEFINE_TO_HEX(int32_t)
DEFINE_TO_HEX(uint32_t)
DEFINE_TO_HEX(int64_t)
DEFINE_TO_HEX(uint64_t)

#undef DEFINE_TO_HEX

