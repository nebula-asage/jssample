#include <openssl/sha.h>
#include "digest/Sha1Hash.h"

namespace digest {

Sha1Hash::Sha1Hash() : _ctx(new SHA_CTX) {
}

Sha1Hash::~Sha1Hash() {
    if (_ctx) {
        auto sha_ctx = reinterpret_cast<SHA_CTX *>(_ctx);
        delete sha_ctx;
    }
}

void Sha1Hash::_initialize() {
    SHA1_Init(reinterpret_cast<SHA_CTX *>(_ctx));
}

void Sha1Hash::_update(const unsigned char *data, size_t size) {
    SHA1_Update(reinterpret_cast<SHA_CTX *>(_ctx), data, size);
}

void Sha1Hash::_finalize(unsigned char *digest) {
    SHA1_Final(digest, reinterpret_cast<SHA_CTX *>(_ctx));
}

} // namespace digest