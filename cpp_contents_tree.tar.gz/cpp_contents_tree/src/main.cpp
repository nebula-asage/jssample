#include <iostream>
#include <vector>


#include <sstream>
#include <iomanip>

#include <limits>

// utils
#include "utils.h"

struct Timestamp {
    uint64_t time;
};

struct HashKey {
    // type
    std::string type;
    // 半角英数小文字・16進数文字列
    std::string id;
};

struct Content {
    HashKey key;
    HashKey version;
    Timestamp created_date;
    Timestamp updated_date;
};



#include "digest/Sha1HashStream.h"

// TODO ハッシュ関数作成
// digest.h, hash.cpp
// sha1.h, sha1.cpp
// -> 256もやる？

using namespace digest;

int main(int argn, char** args) {
    std::cout << "C++ Hello world!!!" << std::endl;
    argn--;
    args++;
    std::cout << "argn : " << argn << std::endl;
    std::vector<std::string> arg_list(args, args + argn);
    for (auto i = 0U; i < arg_list.size(); ++i) {
        std::cout << "   " << i << " : " << arg_list.at(i) << std::endl;
    }

    std::vector<uint8_t> v = {0, 10, 16, 0xff};
    std::cout << to_hex(v) << std::endl;
    std::vector<uint64_t> x{1, 128};
    std::cout << to_hex(x.at(1)) << std::endl;
    std::cout << to_hex(std::numeric_limits<uint8_t>::max()) << std::endl;

    Sha1Hash sha1;
    std::string str = "abc";
    for (auto && c : str) {
        sha1.update(&c, sizeof(c));
    }
    const auto &digest = sha1.digest();
    for (auto && c : digest) {
        std::cout << to_hex(c);
    }
    std::cout << std::endl;

    Sha1HashStream mds;
    mds << "a" << "b";
    mds.write("c", 1);
    
    mds.reset();
    mds << "abc";
    // std::vector<char> v(1024 * 1024 * 1024);
    // mds.write(v.data(), v.size());

    for (auto && c : mds.digest()) {
        std::cout << to_hex(c);
    }
    std::cout << std::endl;

    return 0;
}