#!/bin/bash

set -eu

SCRIPT_DIR=$(cd $(dirname $0); pwd)

BIN=${SCRIPT_DIR}/dst/bin/main

test -e ${BIN} && ${BIN} "$@"