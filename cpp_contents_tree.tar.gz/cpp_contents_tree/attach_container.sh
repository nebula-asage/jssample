#!/bin/bash

set -eu

SCRIPT_DIR=$(cd $(dirname $0); pwd)

IMAGE_NAME=$(cd $(dirname $0);  basename $(pwd))
CONTAINER_NAME=${IMAGE_NAME}

if [ -z "$(docker ps -qa  -f name=${CONTAINER_NAME})" ]; then
    echo "${CONTAINER_NAME} is not running."
    exit 1
fi

docker exec \
    -it \
    --workdir /work \
    ${CONTAINER_NAME} \
    /bin/bash