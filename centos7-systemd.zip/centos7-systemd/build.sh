#!/bin/bash

docker-compose build