#!/bin/bash

docker build --rm -t centos7-systemd .