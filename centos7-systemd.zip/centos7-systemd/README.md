

* どちらか片側のノードで実施する。

    ~~~
    pcs cluster auth -u hacluster -p password123 srv-act srv-sby
    ~~~

* クラスタの同期

    ~~~sh
    pcs cluster setup --name ha-cluster srv-act srv-sby
    ~~~

* クラスタの起動

    ~~~sh
    pcs cluster start --all
    ~~~
<!-- 
    → エラーが出て起動しない。

    ~~~
    [root@centos7-systemd-sby /]# pcs cluster start --all
    centos7-systemd-sby: Error connecting to centos7-systemd-sby - (HTTP error: 400)
    centos7-systemd: Unable to connect to centos7-systemd, try setting higher timeout in --request-timeout option (Operation timed out after 60001 milliseconds with 0 out of -1 bytes received)
    Error: unable to start all nodes
    centos7-systemd: Unable to connect to centos7-systemd, try setting higher timeout in --request-timeout option (Operation timed out after 60001 milliseconds with 0 out of -1 bytes received)
    centos7-systemd-sby: Error connecting to centos7-systemd-sby - (HTTP error: 400)
    ~~~

    aaaa

    ~~~sh
    vi /usr/lib/systemd/system/corosync.service
    ~~~

    ~~~
    # [Service] の Type を変更する。
    # https://github.com/ClusterLabs/pcs/issues/196
    Type=notify
    ~~~

    よくわかんないけどコンテナ作り直したら成功した。
     -->
    
* ステータス確認

    ~~~sh
    pcs status
    ~~~

    `Online:`にノードが含まれていればよい（起動直後しばらく待つ）。

    ~~~
    [root@centos7-systemd /]# pcs status
    Cluster name: ha-cluster

    WARNINGS:
    No stonith devices and stonith-enabled is not false

    Stack: corosync
    Current DC: centos7-systemd (version 1.1.23-1.el7_9.1-9acf116022) - partition with quorum
    Last updated: Sun Apr 16 14:11:38 2023
    Last change: Sun Apr 16 14:10:11 2023 by hacluster via crmd on centos7-systemd

    2 nodes configured
    0 resource instances configured

    Online: [ centos7-systemd centos7-systemd-sby ]

    No resources


    Daemon Status:
    corosync: active/disabled
    pacemaker: active/disabled
    pcsd: active/enabled
    ~~~

* `stonith`の無効化

    - 検証なのでいったんオフ

    ~~~
    pcs property set stonith-enabled=false
    pcs property set no-quorum-policy=ignore
    pcs property
    crm_verify -L -V
    ~~~

https://sky-joker.tech/2017/03/26/centos7%E3%81%ABpacemaker%E3%82%92%E3%82%A4%E3%83%B3%E3%82%B9%E3%83%88%E3%83%BC%E3%83%AB%E3%81%97%E3%81%A6%E3%81%BF%E3%82%8B/
https://tech-mmmm.blogspot.com/2018/11/centos-7-pacemaker-corosyncmariadb.html

https://qiita.com/kamaboko123/items/61b2b4071fe114d69652


* VIP の設定

    ~~~sh
    # pcs resource describe ocf:heartbeat:IPaddr2
    pcs resource create VIP ocf:heartbeat:IPaddr2 \
        ip=192.168.1.254 nic=eth0 cidr_netmask=24 \
        op monitor interval=30s
    ~~~

    ~~~
    not installed' (5): call=5, status=complete, exitreason='Setup problem: couldn't find command: ip
    ~~~

    `ip`コマンドがインストール済みであるにもかかわらずエラーが出る場合、`which`コマンドがインストールされてない

    ~~~sh
    yum install -y which 
    ~~~