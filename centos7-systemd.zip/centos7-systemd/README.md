初期設定
----

* どちらか片側のノードで実施する。

* クラスタ間の認証

    ~~~
    # pcs cluster auth -u hacluster -p password123 srv-act srv-sby inter-connect1-act inter-connect1-sby inter-connect2-act inter-connect2-sby
    
    pcs host auth srv-act srv-sby inter-connect1-act inter-connect1-sby inter-connect2-act inter-connect2-sby -u hacluster -p password123
    ~~~

    ※ 複数のNWがある場合、act,sbyのホスト名の組みで指定する。

* クラスタの同期

    ~~~sh
    # pcs cluster setup --name ha-cluster inter-connect1-act,inter-connect2-act inter-connect1-sby,inter-connect2-sby

    pcs cluster setup ha-cluster \
        srv-act addr=192.168.10.2 addr=192.168.11.2 \
        srv-sby addr=192.168.10.3 addr=192.168.11.3
    ~~~

    - `ha-cluster`は任意のクラスタ名. `srv-act`, `srv-sby` は任意のノード名
    - 同期用のNWが複数ある場合は、`addr`で複数指定する。

* クラスタの起動

    ~~~sh
    pcs cluster start --all
    ~~~

* クラスタの自動起動を設定

    ~~~sh
    pcs cluster enable --all
    ~~~

* ステータス確認

    ~~~sh
    pcs status
    ~~~

    `Online:`にノードが含まれていればよい（起動直後しばらく待つ）。

    ~~~
    [root@srv-act /]# pcs status
    Cluster name: ha-cluster

    WARNINGS:
    No stonith devices and stonith-enabled is not false

    Status of pacemakerd: 'Pacemaker is running' (last updated 2023-05-07 10:18:01Z)
    Cluster Summary:
    * Stack: corosync
    * Current DC: srv-sby (version 2.1.4-5.el9_1.2-dc6eb4362e) - partition with quorum
    * Last updated: Sun May  7 10:18:02 2023
    * Last change:  Sun May  7 10:17:09 2023 by hacluster via crmd on srv-sby
    * 2 nodes configured
    * 0 resource instances configured

    Node List:
    * Online: [ srv-act srv-sby ]

    Full List of Resources:
    * No resources

    Daemon Status:
    corosync: active/disabled
    pacemaker: active/disabled
    pcsd: active/enabled
    ~~~

* ハートビートの確認

    ~~~sh
    corosync-cfgtool -s
    ~~~

    ~~~
    [root@srv-act /]# corosync-cfgtool -s
    Local node ID 1, transport knet
    LINK ID 0 udp
            addr    = 192.168.10.2
            status:
                    nodeid:          1:     localhost
                    nodeid:          2:     connected
    LINK ID 1 udp
            addr    = 192.168.11.2
            status:
                    nodeid:          1:     localhost
                    nodeid:          2:     connected
    ~~~

* クラスタのプロパティを変更

    ~~~
    # stonith は今回検証なので無効化（スプリットブレイン対策
    pcs property set stonith-enabled=false
    # 多数決でアクティブなノードを決定する仕組みだが、Act-Sbyは2台構成で多数決できないので ignore に設定
    pcs property set no-quorum-policy=ignore
    # 確認
    pcs property
    # エラーが出なければOK（stonith が有効なままだとエラーが出る）
    crm_verify -L -V
    ~~~


* RA:仮想IPアドレス（サービス用）の設定

    ~~~sh
    # pcs resource describe ocf:heartbeat:IPaddr2
    pcs resource create ServiceVIP ocf:heartbeat:IPaddr2 \
        ip=192.168.1.254 cidr_netmask=24 \
        op monitor interval=30s \
        meta migration-threshold=0
    ~~~

    ~~~
    not installed' (5): call=5, status=complete, exitreason='Setup problem: couldn't find command: ip
    ~~~

    `ip`コマンドがインストール済みであるにもかかわらずエラーが出る場合、`which`コマンドがインストールされてない

    ~~~sh
    yum install -y which 
    ~~~

    設定確認

    ~~~sh
    ip addr show dev eth1
    ~~~

    ~~~
    [root@srv-act /]# ip addr show dev eth1
    795: eth1@if796: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default 
        link/ether 02:42:c0:a8:01:02 brd ff:ff:ff:ff:ff:ff link-netnsid 0
        inet 192.168.1.2/24 brd 192.168.1.255 scope global eth1
        valid_lft forever preferred_lft forever
        inet 192.168.1.254/24 brd 192.168.1.255 scope global secondary eth1
        valid_lft forever preferred_lft forever
    ~~~

* RA:共有ディスクのマウント設定

    - 今回は検証なのでnfsで代用

    ~~~sh
    mkdir -p /mnt/nfs-share
    pcs resource create ShareDir ocf:heartbeat:Filesystem \
        device=nfs-server:/ directory=/mnt/nfs-share fstype=nfs4 \
        op monitor interval=30s \
        meta migration-threshold=0
    ~~~

* TODO PostgreSQL

* RA:仮想IPアドレス（監視用）の設定

    ~~~sh
    pcs resource create MonitorVIP ocf:heartbeat:IPaddr2 \
        ip=192.168.20.254 cidr_netmask=24 \
        op monitor interval=30s
    ~~~


* リソースグループにまとめる.

    - RA設定しただけだと、RAごとにAct,Sby異なるノードで起動する
    - リソースグループにまとめておくと、同じノードですべて起動し、フェイルオーバー時もまとめてフェイルオーバーされる。

    ~~~sh
    pcs resource group add resource-group ServiceVIP ShareDir 
    ~~~

    - 順番に注意。指定順に起動、逆順に停止の順になる。
    - 監視用VIPは含めない（監視用NWは自動でフェイルオーバーしてほしい）

手動フェイルオーバー
----
* リソースグループ名を指定してまとめてフェイルオーバーさせる

    - → ちがう
    ~~~sh
    # pcs resource move resource-group
    pcs node standby srv-act
    ~~~

* 

    ~~~sh
    pcs resource failcount
    ~~~

    ~~~sh
    pcs resource cleanup
    ~~~

TODO ノード停止時のフェイルオーバーのオフ

* 参考

    https://sky-joker.tech/2017/03/26/centos7%E3%81%ABpacemaker%E3%82%92%E3%82%A4%E3%83%B3%E3%82%B9%E3%83%88%E3%83%BC%E3%83%AB%E3%81%97%E3%81%A6%E3%81%BF%E3%82%8B/

    https://tech-mmmm.blogspot.com/2018/11/centos-7-pacemaker-corosyncmariadb.html

    https://qiita.com/kamaboko123/items/61b2b4071fe114d69652

    https://www.bigbang.mydns.jp/pacemaker-x.htm

