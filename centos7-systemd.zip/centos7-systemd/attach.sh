#!/bin/bash

docker exec -it centos7-systemd /bin/bash 
