#!/bin/bash

docker-compose exec "$@" /bin/bash 
