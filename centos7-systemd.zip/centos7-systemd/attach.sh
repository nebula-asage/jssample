#!/bin/bash

SERVICE_NAME="$1"

docker-compose exec ${SERVICE_NAME} /bin/bash 
