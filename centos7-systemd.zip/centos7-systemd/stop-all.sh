#!/bin/bash

docker stop centos7-systemd
docker stop centos7-systemd-sby
