#!/bin/bash 

echo "start server."

# Pacemaker インストール時に作成されるユーザ(hacluster)のパスワード設定
# → クラスタ初期設定時のクラスタ間の認証に用いる
if [ "${HACLUSTER_PASSWORD}" != "" ] ; then
    echo ${HACLUSTER_PASSWORD} | passwd --stdin hacluster
fi

# 検証なので root ユーザでの ssh ログインは許可しておく
sed -i \
    -e "s/#PermitRootLogin prohibit-password/PermitRootLogin yes/g" \
    /etc/ssh/sshd_config

# SSH ログイン用のパスワード設定
if [ "${SSH_PASSWORD}" != "" ] ; then
    echo ${SSH_PASSWORD} | passwd --stdin root
fi

exec /usr/sbin/init