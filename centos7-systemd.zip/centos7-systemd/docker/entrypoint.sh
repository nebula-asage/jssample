#!/bin/bash 

echo "start server."

if [ "${HACLUSTER_PASSWORD}" != "" ] ; then
    echo ${HACLUSTER_PASSWORD} | passwd --stdin hacluster
fi

exec /usr/sbin/init