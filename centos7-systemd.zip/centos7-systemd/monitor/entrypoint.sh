#!/bin/bash

tail -f /dev/null