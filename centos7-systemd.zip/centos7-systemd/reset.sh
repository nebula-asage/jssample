#!/bin/bash 

docker-compose down \
    --volumes 