#!/bin/bash 

# systemctl start pcsd

echo "start server."

exec /usr/sbin/init


tail -f /dev/null