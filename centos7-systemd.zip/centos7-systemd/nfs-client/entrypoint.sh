#!/bin/bash

mount -v -t nfs4 nfs-server:/ /mnt/nfs-share

tail -f /dev/null