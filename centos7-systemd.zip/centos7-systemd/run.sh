#!/bin/bash 

# nfs サーバのイメージは github から Dockerfile を取得して利用
curl -L -s -o nfs-server/Dockerfile https://raw.githubusercontent.com/GoogleCloudPlatform/nfs-server-docker/master/1/debian11/1.3/Dockerfile
curl -L -s -o nfs-server/docker-entrypoint.sh https://raw.githubusercontent.com/GoogleCloudPlatform/nfs-server-docker/master/1/debian11/1.3/docker-entrypoint.sh

docker-compose up \
    --build \
    --detach \
    --force-recreate  