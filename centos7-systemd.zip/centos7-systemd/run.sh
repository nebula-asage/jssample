#!/bin/bash 


docker run \
	--name centos7-systemd \
	--hostname centos7-systemd \
	--privileged \
	--cap-add=SYS_ADMIN \
	--rm \
	--detach \
	-it \
	-v /sys/fs/cgroup:/sys/fs/cgroup:ro \
	--net pcs-network \
	centos7-systemd

docker exec -it centos7-systemd /bin/bash 
