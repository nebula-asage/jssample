#include <iostream>
#include <vector>


int main(int argn, char** args) {
    std::cout << "C++ Hello world!!!" << std::endl;
    argn--;
    args++;
    std::cout << "argn : " << argn << std::endl;
    std::vector<std::string> arg_list(args, args + argn);
    for (auto &&v : arg_list) {
        std::cout << "     : " << v << std::endl;
    }
    return 0;
}