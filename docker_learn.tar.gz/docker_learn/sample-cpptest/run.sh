#!/bin/bash

# 環境変数とか
NAME=cpptest
IMAGE=sample/${NAME}
WORKDIR=tmp

# Dockerfile からイメージを作成する。
# 繰り返し実行しても問題ない模様。
docker build --build-arg WORKDIR=${WORKDIR} -t ${IMAGE} .

# Dockerコンテナの作成と起動
#（rm オプションにより停止後に自動で破棄される）
docker run -it -a stdout --rm -v $(pwd):/${WORKDIR} --name ${NAME} -e ABC=XXX ${IMAGE} "$@"

# docker stop ${NAME}

# 実行結果出力. `-a stdout` を付けたので不要
# docker logs ${NAME}

# --rm を付けてる場合、以下は不要。 
# docker rm ${NAME}