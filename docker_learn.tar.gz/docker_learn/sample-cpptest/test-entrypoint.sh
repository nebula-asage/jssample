#!/bin/bash

set -e

# entrypoint はbuild & run

cd ${WORKDIR}

if [ -e main.cpp ] ;then 
    g++ --std=c++11 main.cpp
    ./a.out "$@"
fi

cd ../