Docker learn.
=====

Dockerの実行環境
----

* Docker Desktop
    - OSネイティブな仮装化機能で実行するので、性能が良い。
    - Dockerのアカウントが必要。
    - 仮装化Windows 10 Pro以降でないといけない。
    - 将来的にWSL2になれば本物のLinuxカーネルがWindows10に含まれることになるので、
      仮装環境でなくてもDockerが動くようになるかも。
      （WSL2 -> Windows Subsystem for Linux2）

* Docker Tool Box
    - 実体はVirtualBox上で動作するLinux仮想マシンで実行する。
    - Windows7ではこっちを使う。

Docker基本コマンド編
----

### イメージ管理
* CentOS7のイメージを取得する。

    ```sh
    docker pull centos:centos7
    ```

    イメージ名:タグ名

    Dockerhub からイメージをダウンロードする。

* イメージからコンテナを作成する。

    ```sh
    docker create --name centos7 -it centos:centos7 
    ```

    - `-name` : コンテナの名前

* イメージのリストを表示

    ```sh
    docker images
    ```

* イメージの削除

    ```sh
    docker rmi <タグ名:イメージ名>
    ```

* none 不要イメージの削除

    イメージのビルドを繰り返していると、ゴミイメージが溜まってくる。

    ~~~
    REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
    <none>              <none>              ac36d34661a7        44 hours ago        394MB
    <none>              <none>              b15fb06dbdb4        44 hours ago        394MB
    <none>              <none>              c13e2d3e61c5        44 hours ago        394MB
    ~~~

    最新（`1.25`以降）のDockerでは以下のコマンドで全て削除できる。
    
    ```sh
    docker image prune
    ```

    参考：
    - [Dockerで none なイメージを一括で削除するワンライナー](https://qiita.com/DQNEO/items/e3a03a14beb616630032)
    - [docker image prune](https://docs.docker.com/engine/reference/commandline/image_prune/)

    

---

### コンテナ管理

* コンテナの起動
  
    ```sh
    docker start centos7
    ```

* コンテナの作成と起動する。

    docker pull, create, startを纏めて実行するコマンド。

    ```sh
    docker run -it -d --name centos7 centos:centos7
    ```

    - `-it` : コンテナのプロセスにttyを割り当てる。
        - とりあえず必ず付けておけば良い。
    - `-d` : バックグラウンド起動
    - `-name` : コンテナの名前

* コンテナの起動確認
  
    ```sh
    docker ps -a
    ```

    - `-a` : 停止しているコンテナも表示。

* コマンド実行

    ```sh
    docker exec 
    ```

* コンテナにBashでアクセス

    ```sh
    docker exec -it centos7 bash
    ```

* コンテナの停止

    ```sh
    docker stop centos7
    ```

* コンテナの削除

    コンテナが停止済みであること。

    ```sh
    # コンテナの停止
    docker stop centos7
    # コンテナの削除
    docker rm centos7
    # コンテナの削除確認
    docker ps -a
    ```

* コンテナの差分確認

    ```sh
    docker diff centos7
    ```

## Dockerfile

https://qiita.com/xyx/items/67842fbf3a25a996c2a0

参考
----

https://weblabo.oscasierra.net/docker-centos7/