// @file wsh

var WSHProperties = {
    scriptFullName: WScript.ScriptFullName,
    buildVersion: WScript.BuildVersion,
    fullName: WScript.FullName,
    name: WScript.Name,
    path: WScript.Path,
    scriptName: WScript.ScriptName,
    version: WScript.Version,
    currentDirPath: WScript.CreateObject("WScript.Shell").CurrentDirectory
};


// wscript, cscript両方で有効
function echo(message) {
    WScript.Echo(message);
}

// cscript(StdOut,StdErr)でのみ有効

function print(message) {
    WScript.StdOut.Write(message);
}

function println(message) {
    WScript.StdOut.WriteLine(message);
}

function eprint(message) {
    WScript.StdErr.Write(message);
}

function eprintln(message) {
    WScript.StdErr.WriteLine(message);
}

function sleep(ms) {
    WScript.Sleep(ms);
}

function quit(code) {
    try {
        // JScriptエンジン指定だと、なぜか実行できない
        // cscript /E:{16d51579-a30b-4c8b-a276-0ff4dc41e755} xxx.js
        WScript.Quit(code);
    } catch (e) {
        // no-op
    }
}

function getArguments() {
    var length = WScript.Arguments.length;
    var args = [];
    for (var i = 0; i < length; i++) {
        args.push(WScript.Arguments(i));
    }
    return args;
}

(function () {

})();