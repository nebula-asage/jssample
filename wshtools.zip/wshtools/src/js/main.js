/**
 * メイン処理
 * 
 * @param {Array} args 引数リスト。
 * @param {function} done 完了通知コールバック。
 * @param {function} fail 失敗通知コールバック。
 * @return {undefined|number|Promise} 実行結果(数値の場合0:正常終了、1:異常終了、-1:非同期モード（done、またはfailで完了を通知すること）、Promise:非同期モード） 
 */
function main(args, done, fail) {
    // TODO your code goes here
    return 0;
}