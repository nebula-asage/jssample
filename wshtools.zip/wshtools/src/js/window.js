(function (global) {

    // htmlのwindowオブジェクトを利用可能にする。

    // https://gist.github.com/nissuk/1073781/6903d90033bc0407dd61bcc52b02f0d1c93b6b68

    // documentオブジェクトを作成
    var htmlfile = new ActiveXObject("htmlfile");
    htmlfile.write("<html></html>");

    // windowオブジェクトの代替
    var window = htmlfile.parentWindow;
    if (typeof global.window === "undefined") {
        global.window = window;
    }
    if (typeof global.document === "undefined") {
        global.document = window.document;
    }
    if (typeof global.alert === "undefined") {
        global.alert = function (str) {
            return window.alert(str);
        };
    }

    if (typeof global.confirm === "undefined") {
        global.confirm = function (str) {
            return window.confirm(str);
        };
    }
    if (typeof global.location === "undefined") {
        global.location = window.location;
    }

    if (typeof global.navigator === "undefined") {
        global.navigator = window.navigator;
    }

    // setInterval関連
    if (typeof global.setInterval === "undefined") {
        global.setInterval = function (code, interval) {
            return window.setInterval(code, interval);
        };
    }
    if (typeof global.clearInterval === "undefined") {
        global.clearInterval = function (id) {
            return window.clearInterval(id);
        };
    }

    // setTimeout関連
    if (typeof global.setTimeout === "undefined") {
        global.setTimeout = function (code, delay) {
            return window.setTimeout(code, delay);
        };
    }
    if (typeof global.clearTimeout === "undefined") {
        global.clearTimeout = function (id) {
            return window.clearTimeout(id);
        };
    }
    window.ActiveXObject = ActiveXObject;
})(this);