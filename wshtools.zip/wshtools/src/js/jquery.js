(function (global) {
    // $のエイリアスをグローバルに定義
    if (typeof global.$ === "undefined" &&
        typeof global.window !== "undefined" &&
        typeof global.window.$ !== "undefined") {
        global.$ = global.window.$;
        // クロスドメインアクセスを許可
        // http://piyopiyocs.blog115.fc2.com/blog-entry-622.html
        global.$.support.cors = true;
    }

})(this);