(function () {

    var STATUS_OK = 0;
    var STATUS_NG = 1;
    var isStop = false;
    var done = function done(code) {
        isStop = true;
        quit(code || STATUS_OK);
    };
    var fail = function fail(e) {
        if (e instanceof Error) {
            eprintln("Error details : " + e.message);
        }
        isStop = true;
        quit(STATUS_NG);
    };
    var retval = null;
    var isThenable = false;
    try {
        retval = main(getArguments(), done, fail);
        isThenable = retval instanceof Promise;
        if (!isThenable && 0 <= (retval | 0)) {
            // 同期モードの場合(retvalが0以上)
            done(retval);
            return;
        }
    } catch (e) {
        fail(e);
        return;
    }

    if (isThenable) {
        // 非同期モードの場合(retvalがPromise)
        // wshではcatchが予約語なのでやむなくキーアクセスする。
        retval["then"](done)["catch"](fail);
    }

    // 非同期モードの場合の待ち合わせ
    while (!isStop) {
        sleep(100);
    }

})(this);