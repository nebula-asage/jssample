(function (global) {
    // es6-promiseのエイリアスをグローバルに定義
    if (typeof global.Promise === "undefined" &&
        typeof global.ES6Promise !== "undefined") {
        global.Promise = global.ES6Promise;
    }
})(this);