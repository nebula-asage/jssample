/// @file common.js

function isNumber(v) {
    return typeof v === "number" || v instanceof Number;
}

function isBoolean(v) {
    return typeof v === "boolean" || v instanceof Boolean;
}

function isString(v) {
    return typeof v === "string" || v instanceof String;
}

function isArray(v) {
    return v instanceof Array;
}

function isFunction(v) {
    return typeof v === "function";
}

function toArray(a) {
    return Array.prototype.slice.call(a);
}