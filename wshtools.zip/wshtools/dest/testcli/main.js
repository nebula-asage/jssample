function main(args, done, fail) {
    echo("args : " + JSON.stringify(args, null, "\t"));
    // your code goes here
    println("Hello world!");
    // es5 support.
    println([1, 2, 3].map(function (v) {
        return v + 1;
    }));
    // json support.
    println(JSON.stringify({
        abc: 123,
        def: 456,
        ghi: ["a", "b", "c"]
    }));
    println(JSON.stringify(WSHProperties, null, "\t"));
    // WScript.Echo(ScriptEngine() + '/' + [ScriptEngineMajorVersion(), ScriptEngineMinorVersion(), ScriptEngineBuildVersion()].join('.'));
    // return 0;
    // $.ajax({
    //     "url": "https://www.google.co.jp",
    //     success: function (ret) {
    //         println("success");
    //         done();
    //     },
    //     error: function (e) {
    //         eprintln(JSON.stringify(e));
    //         fail();
    //     }
    // });
    // return -1;

}