// 必須機能インポート
const fs = require("fs");
const mkdirp = require("mkdirp");
const del = require("del");
const execSync = require("child_process").execSync;
const runSequence = require("run-sequence");
const merge = require("event-stream").merge;
const gulp = require("gulp");
const rename = require("gulp-rename");
const concat = require("gulp-concat");

// 環境変数取得
const commandName = process.env.COMMAND_NAME ? process.env.COMMAND_NAME.trim() : undefined;
console.log(`COMMAND_NAME : ${commandName}`);
// TODO 
if (!commandName) {
    throw new Error(`環境変数「COMMAND_NAME」を指定してください。`);
}

// 変数
const destDir = "dest";
const cmdDir = `dest/${commandName}`
const cmdBinDir = `${cmdDir}/bin`;
const srcDir = "src";
const srcJsDir = `${srcDir}/js`;
const srcBinDir = `${srcDir}/bin`;
const libDir = "lib"
const mainFileName = "main.js";
const mainFilePath = `${srcJsDir}/${mainFileName}`;
const batFilePath = `${srcBinDir}/app.bat`;
const jsFileName = `app.js`;

function pathExists(path) {
    try {
        fs.statSync(path);
        return true;
    } catch (e) {
        return false;
    }
}

gulp.task("init", () => {

    mkdirp.sync(cmdBinDir);
    if (!pathExists(`${cmdDir}/${mainFileName}`)) {
        return gulp.src(mainFilePath)
            .pipe(gulp.dest(cmdDir));
    }
});

gulp.task("build", ["clean"], () => {
    return merge([
        gulp.src(batFilePath)
            .pipe(rename(`${commandName}.bat`))
            .pipe(gulp.dest(cmdBinDir)),

        gulp.src([
            `${cmdDir}/${mainFileName}`,
            `${srcJsDir}/wsh.js`,
            `${libDir}/es5-shim/es5-shim.min.js`,
            `${libDir}/json3/json3.min.js`,
            `${srcJsDir}/window.js`,
            // jquery 1.10以降では動作しない
            `${libDir}/jquery/jquery-1.9.1.min.js`,
            `${libDir}/es6promise/es6-promise.min.js`,
            `${srcJsDir}/promise.js`,
            `${srcJsDir}/jquery.js`,
            `${srcJsDir}/command.js`
        ])
            .pipe(concat(jsFileName))
            .pipe(gulp.dest(cmdBinDir))
    ]);

});

gulp.task("watch", ["build"], () => {
    return gulp.watch(
        [
            `${cmdDir}/${mainFileName}`,
            `${srcBinDir}/*.bat`,
            `${srcJsDir}/*.js`
        ],
        () => {
            return runSequence("build", "main");
        }

    );
});


gulp.task("clean", ["init"], () => {
    del.sync(`${cmdBinDir}/*`);
});

gulp.task("main", () => {
    const ret = execSync(`"${cmdBinDir}/${commandName}.bat"`).toString();
    console.log(`result : ${ret}`);
});



