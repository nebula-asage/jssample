
function main() {

    foo();

    // echo(JSON);
    echo("abc!");
    return 0;
}

function foo() {
    var cnt = 10000000;
    var v = 0;
    var start = (new Date()).getTime();
    for (var i = 0; i < cnt; i++) {
        v += i;
        v = v * Math.random();
    }
    println((new Date()).getTime() - start);
}
// wsh common

function echo(message) {
    WScript.Echo(message);
}

function print(message) {
    WScript.StdOut.Write(message);
}

function println(message) {
    WScript.StdOut.WriteLine(message);
}
function eprint(message) {
    WScript.StdErr.Write(message);
}

function eprintln(message) {
    WScript.StdErr.WriteLine(message);
}

function sleep(ms) {
    WScript.Sleep(ms);
}

function quit(code) {
    try {
        WScript.Quit(code);
    } catch (e) {
        // no-op
    }
}
// wsh fs




// main
(function () {
    try {
        // WScript.Quit(main());
        return main();
    } catch (e) {
        eprintln(e.message);
        //WScript.Quit(1);
        throw e;
    }
})();