#!/bin/bash 

g++ \
    --std=c++17 \
    -O0 \
    -g \
    -Wall -Wextra \
    -pedantic \
    src/SQLParser.cpp
