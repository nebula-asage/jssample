#!/bin/bash
clear
./build.sh && time ./a.out "$@"