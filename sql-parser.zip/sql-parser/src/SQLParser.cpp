#include <iostream>
#include <cmath>
#include <memory>
#include <optional>
#include <string>
#include <type_traits>
#include <variant>
#include <vector>
#include <boost/spirit/include/qi.hpp>
#include <boost/spirit/include/phoenix.hpp>
#include <boost/phoenix/bind.hpp>

namespace util {

template<typename T>
std::vector<T> concat(const std::vector<T> &a, const std::vector<T> &b) {
    std::vector<T> result;
    std::copy(a.begin(), a.end(), std::back_inserter(result));
    std::copy(b.begin(), b.end(), std::back_inserter(result));
    return result;
}

// 小数点以下の桁数を数える
int count_scale(double num) {
    int count = 0;
  	double v = num;
    while (v != std::floor(v)) {
        v = num * std::pow(10, ++count);
    }
    return count;
}

} // namespace util

namespace sql::ast {

// 構文
struct Syntax {
    virtual ~Syntax() = default;

};

// 文の基底クラス
struct Statement : public Syntax {
    virtual ~Statement() = default;

};

struct EmptyStatement : public Statement {
};

class Node;

struct SelectCondition : public Syntax {

    SelectCondition(const std::shared_ptr<Node> node, const std::optional<std::string> &alias = std::optional<std::string>()) : 
        node(node), alias(alias) {
    }
    const std::shared_ptr<Node> node;
    std::optional<std::string> alias;

};

struct SelectAsterisk : public Syntax {
    SelectAsterisk(const std::optional<std::string> &table_name = std::optional<std::string>()) : table_name(table_name) {
    }
    std::optional<std::string> table_name;
};

struct SelectStatement: public Statement {
    SelectStatement(const std::vector<std::shared_ptr<Syntax>> &select_list) : 
        select_list(select_list) {
    }

    const std::vector<std::shared_ptr<Syntax>> select_list;
};

struct TableReference : public Syntax {
    TableReference(
        const std::string &table_name,
        const std::optional<std::string> &alias = std::optional<std::string>()
    ) : table_name(table_name), alias(alias) {
    }

    const std::string table_name;
    const std::optional<std::string> alias;
};


struct FromCause : public Syntax {
    FromCause() {
    }
    // TODO
};

enum class NodeType {

    kOr,
    kAnd,
    kNot,

    kIsNull,

    kEquals,
    kLessThan,
    kLessEqual, 
    kGreaterThan,
    kGreaterEqual,

    kAdd,
    kSub,
    kMul,
    kDiv,

    kDecimalValue,
    kStringValue,
    kNullValue,
    kAttrValue,

};

std::string node_name(NodeType type) {
    switch (type)
    {
    case NodeType::kOr:
        return "OR";
    case NodeType::kAnd:
        return "AND";
    case NodeType::kNot:
        return "NOT";
    case NodeType::kIsNull:
        return "IS_NULL";
    case NodeType::kEquals:
        return "EQ";
    case NodeType::kLessThan:
        return "LT";
    case NodeType::kLessEqual:
        return "LE";
    case NodeType::kGreaterThan:
        return "GT";
    case NodeType::kGreaterEqual:
        return "LE";
    case NodeType::kAdd:
        return "ADD";
    case NodeType::kSub:
        return "SUB";
    case NodeType::kMul:
        return "MUL";
    case NodeType::kDiv:
        return "DIV";
    case NodeType::kDecimalValue:
        return "DECIMAL";
    case NodeType::kStringValue:
        return "STRING";
    case NodeType::kNullValue:
        return "NULL";
    case NodeType::kAttrValue:
        return "ATTR";
    default:
        throw std::runtime_error("invalid type : " + std::to_string(int(type)));
    }
}

struct Node {

    virtual ~Node() = default;

    virtual NodeType type() const = 0;
};

struct ComputationTreeNode : public Node {

    ComputationTreeNode(NodeType type) : _type(type) {
    }
    virtual ~ComputationTreeNode() = default;

    NodeType type() const {
        return _type;
    }

    const NodeType _type;

};

struct UnaryOperationNode : public ComputationTreeNode {
    UnaryOperationNode(NodeType type, std::shared_ptr<Node> child) : 
        ComputationTreeNode(type), child(child) {
    }
    
    virtual ~UnaryOperationNode() = default;

    const std::shared_ptr<Node> child;

};

struct BinaryOperationNode : public ComputationTreeNode {
    BinaryOperationNode(NodeType type, std::shared_ptr<Node> lhs, std::shared_ptr<Node> rhs) :
        ComputationTreeNode(type), lhs(lhs), rhs(rhs) {
    }

    virtual ~BinaryOperationNode() = default;
    const std::shared_ptr<Node> lhs;
    const std::shared_ptr<Node> rhs;
};

struct DecimalOperandNode : public ComputationTreeNode {
    DecimalOperandNode(double value) : 
        ComputationTreeNode(NodeType::kDecimalValue), value(value), is_signed(value < 0), scale(util::count_scale(value)) {
    }
    virtual ~DecimalOperandNode() = default;
    const double value;
    const bool is_signed;
    const uint64_t scale;

};

struct StringOperandNode : public ComputationTreeNode {
    StringOperandNode(const std::string& value) : 
        ComputationTreeNode(NodeType::kStringValue), value(value) {
    }
    virtual ~StringOperandNode() = default;
    const std::string value;
};

struct NullValueOperandNode : public ComputationTreeNode {
    NullValueOperandNode() : ComputationTreeNode(NodeType::kNullValue) {
    };
    virtual ~NullValueOperandNode() = default;
};

struct AttrValueOperandNode : public ComputationTreeNode {
    AttrValueOperandNode(
        const std::string& column_name,
        const std::optional<std::string> &table_name = std::optional<std::string>()
    ) : ComputationTreeNode(NodeType::kAttrValue), column_name(column_name), table_name(table_name) {
    }
    virtual ~AttrValueOperandNode() = default;
    const std::string column_name;
    std::optional<std::string> table_name;
};

} // sql::ast

//
// boost alias
//

namespace qi = boost::spirit::qi;
namespace ph = boost::phoenix;

using namespace sql::ast;

// sql::ast alias
using SyntaxPtr = std::shared_ptr<sql::ast::Syntax>;
using StatementPtr = std::shared_ptr<sql::ast::Statement>;
using SelectStatementPtr = std::shared_ptr<sql::ast::SelectStatement>;

using NodePtr = std::shared_ptr<sql::ast::Node>;

using Variant = std::variant<
    SyntaxPtr,
    std::vector<SyntaxPtr>,
    NodePtr,
    std::string
>;


class SqlSemanticAction {
public:
    SqlSemanticAction() = default;
    virtual ~SqlSemanticAction() = default;

    SyntaxPtr make_empty_statement() {
        return std::make_shared<EmptyStatement>();
    }

    std::vector<SyntaxPtr> make_syntax_as_list(const Variant& a) {
        if (auto v = std::get_if<SyntaxPtr>(&a)) {
            return std::vector<SyntaxPtr>{*v};
        } else if (auto v = std::get_if<std::vector<SyntaxPtr>>(&a)) {
            return *v;
        }
        return std::vector<SyntaxPtr>{};
    }

    std::vector<SyntaxPtr> make_syntax_list(const Variant& a, const Variant &b) {
        return util::concat(make_syntax_as_list(a), make_syntax_as_list(b));
    }

    SyntaxPtr make_select_statement(const Variant& a) {
        return std::make_shared<SelectStatement>(std::get<std::vector<SyntaxPtr>>(a));
    }

    SyntaxPtr make_select_condition(const Variant& a) {
        return std::make_shared<SelectCondition>(std::get<NodePtr>(a));
    }

    SyntaxPtr make_select_condition_with_as(const Variant& cond, const Variant& alias) {
        auto v = std::static_pointer_cast<SelectCondition>(std::get<SyntaxPtr>(cond));
        v->alias = std::get<std::string>(alias);
        return v;
    }

    SyntaxPtr make_select_asterisk() {
        // TODO テーブル名
        return std::make_shared<SelectAsterisk>();
    }

    NodePtr make_unary_operator(NodeType type, const Variant& child) {
        return std::make_shared<UnaryOperationNode>(type, std::get<NodePtr>(child));
    }

    NodePtr make_binary_operator(NodeType type, const Variant& lhs, const Variant &rhs) {
        return std::make_shared<BinaryOperationNode>(type, std::get<NodePtr>(lhs), std::get<NodePtr>(rhs));
    }

    NodePtr make_or_operator(const Variant& lhs, const Variant &rhs) {
        return make_binary_operator(NodeType::kOr, lhs, rhs);
    }

    NodePtr make_and_operator(const Variant& lhs, const Variant &rhs) {
        return make_binary_operator(NodeType::kAnd, lhs, rhs);
    }

    NodePtr make_not_operator(const Variant& child) {
        return make_unary_operator(NodeType::kNot, child);
    }

    NodePtr make_is_null_predicate(const Variant& child) {
        return make_unary_operator(NodeType::kIsNull, child);
    }

    NodePtr make_is_not_null_predicate(const Variant& child) {
        return make_not_operator(make_is_null_predicate(child));
    }
    
    NodePtr make_comparison_operator(NodeType type, const Variant& lhs, const Variant &rhs) {
        if (type == NodeType::kEquals) {
            if (std::get<NodePtr>(rhs)->type() == NodeType::kNullValue) {
                // 等号比較で右辺がNULLの場合、IS NULL ノードとする。
                return make_is_null_predicate(lhs);
            }
        }
        return make_binary_operator(type, lhs, rhs);
    }

    NodePtr make_not_euality_operator(const Variant& lhs, const Variant &rhs) {
        return make_not_operator(make_comparison_operator(NodeType::kEquals, lhs, rhs));
    }

    NodePtr make_arithmetic_operator(NodeType type, const Variant& lhs, const Variant &rhs) {
        return make_binary_operator(type, lhs, rhs);
    }

    NodePtr make_decimal_operand(double v) {
        return std::make_shared<DecimalOperandNode>(v);
    }

    NodePtr make_string_operand(const std::string &v) {
        return std::make_shared<StringOperandNode>(v);
    }

    NodePtr make_null_value_operand() {
        return std::make_shared<NullValueOperandNode>();
    }

    NodePtr make_attr_value_operand(const Variant &v) {
        // TODO テーブル名
        return std::make_shared<AttrValueOperandNode>(std::get<std::string>(v));
    }

};


template<typename Iterator>
struct CommentGrammer : public qi::grammar<Iterator> {
public : 

    // 参考
    // https://oki-miyuki.github.io/boost_spirit_guide/skipper.html

    using Rule = qi::rule<Iterator>;

    CommentGrammer() : CommentGrammer::base_type(comment) {
        comment = qi::standard::space | inline_comment | multiline_comment;
        multiline_comment = qi::lit("/*") >> *(qi::standard::char_ - qi::lit("*/") - qi::eoi) >> qi::lit("*/");
        inline_comment = qi::lit("--") >> *(qi::standard::char_ - qi::eol -qi::eoi) >> (qi::eol | qi::eoi);
    }
private :
    Rule comment;
    Rule inline_comment;
    Rule multiline_comment;
};


template<typename Iterator, typename Skipper>
struct SQLGrammer : public qi::grammar<Iterator, Variant(), Skipper> {
public:
    using Rule = qi::rule<Iterator, Variant(), Skipper>;

    Rule statement_list;
    Rule statement;
    Rule select_statement;
    Rule select_list;
    Rule select_element;
    Rule select_condition;
    Rule select_condition_with_as;
    Rule select_condition_without_as;

    // expression
    Rule logical_expression;
    Rule logical_term;
    Rule logical_factor;
    Rule logical_factor_with_not;
    Rule logical_factor_without_not;
    // Rule comparison_operator;
    Rule comparison_expression;

    // Rule additive_operator;
    // Rule multiplicative_operator;
    Rule arithmetic_expression;
    Rule arithmetic_term;
    Rule arithmetic_factor;

    // operand
    Rule operand;
    Rule decimal_value;
    Rule quoted_string;
    Rule null_value;
    Rule attr_value;

    Rule identifier;

    // token
    Rule keyword_all;
    Rule keyword_and;
    Rule keyword_as;
    Rule keyword_from;
    Rule keyword_is;
    Rule keyword_not;
    Rule keyword_null;
    Rule keyword_or;
    Rule keyword_select;


    SQLGrammer() : SQLGrammer::base_type(statement_list) {
        
        statement_list = 
            statement[qi::_val = ph::bind(&Action::make_syntax_as_list, &action, qi::_1)] 
                >> *(qi::lit(";") >> statement[qi::_val = ph::bind(&Action::make_syntax_list, &action, qi::_val, qi::_1)]);

        statement = 
            (select_statement[qi::_val = qi::_1] | qi::lit("")[qi::_val = ph::bind(&Action::make_empty_statement, &action)]);

        select_statement = 
            keyword_select >> -(keyword_all) >> select_list[qi::_val = ph::bind(&Action::make_select_statement, &action, qi::_1)];

        select_list = 
            select_element[qi::_val = ph::bind(&Action::make_syntax_as_list, &action, qi::_1)] 
                >> *(qi::lit(",") >> select_element[qi::_val = ph::bind(&Action::make_syntax_list, &action, qi::_val, qi::_1)]);

        select_element = select_condition[qi::_val = qi::_1] | qi::lit("*")[qi::_val = ph::bind(&Action::make_select_asterisk, &action)]; // TODO テーブル名

        select_condition_without_as = 
            (logical_expression | arithmetic_expression)[qi::_val = ph::bind(&Action::make_select_condition, &action, qi::_1)];
        select_condition_with_as = select_condition_without_as[qi::_val = qi::_1] >> -(keyword_as) >> identifier[qi::_val = ph::bind(&Action::make_select_condition_with_as, &action, qi::_val, qi::_1)];
        // asあり⇒as なしの順にすること（先に「asなし」にすると「asなし」と解釈されるため）
        select_condition = (select_condition_with_as | select_condition_without_as)[qi::_val = qi::_1];

        // 式
        logical_expression = 
            logical_term[qi::_val = qi::_1] 
                >> *(keyword_or >> logical_term[qi::_val = ph::bind(&Action::make_or_operator, &action, qi::_val, qi::_1)]);
        
        logical_term = 
            logical_factor[qi::_val = qi::_1] 
                >> *(keyword_and >> logical_factor[qi::_val = ph::bind(&Action::make_and_operator, &action, qi::_val, qi::_1)]);
        
        logical_factor_without_not = (comparison_expression | qi::lit("(") >> logical_expression >> qi::lit(")"))[qi::_val = qi::_1];
        logical_factor_with_not = keyword_not >> logical_factor_without_not[qi::_val = ph::bind(&Action::make_not_operator, &action, qi::_1)];
        // notあり⇒ not なしの順にすること
        logical_factor = (logical_factor_with_not | logical_factor_without_not)[qi::_val = qi::_1];

        // comparison_operator = qi::lit("==") | qi::lit("=") | qi::lit("<>") | qi::lit("!=") | qi::lit("<=") | qi::lit("<") | qi::lit(">=")  | qi::lit(">");
        comparison_expression = arithmetic_expression[qi::_val = qi::_1] >> (
                ((qi::lit("==") | qi::lit("=")) >> arithmetic_expression[qi::_val = ph::bind(&Action::make_comparison_operator, &action, NodeType::kEquals, qi::_val, qi::_1)]) |
                ((qi::lit("<>") | qi::lit("!=")) >> arithmetic_expression[qi::_val = ph::bind(&Action::make_not_euality_operator, &action, qi::_val, qi::_1)]) |
                (qi::lit("<=") >> arithmetic_expression[qi::_val = ph::bind(&Action::make_comparison_operator, &action, NodeType::kLessEqual, qi::_val, qi::_1)]) |
                (qi::lit("<") >> arithmetic_expression[qi::_val = ph::bind(&Action::make_comparison_operator, &action, NodeType::kLessThan, qi::_val, qi::_1)]) |
                (qi::lit(">=") >> arithmetic_expression[qi::_val = ph::bind(&Action::make_comparison_operator, &action, NodeType::kGreaterEqual, qi::_val, qi::_1)]) |
                (qi::lit(">") >> arithmetic_expression[qi::_val = ph::bind(&Action::make_comparison_operator, &action, NodeType::kGreaterThan, qi::_val, qi::_1)]) |
                (keyword_is >> keyword_null)[qi::_val = ph::bind(&Action::make_is_null_predicate, &action, qi::_val)] | 
                (keyword_is >> keyword_not >> keyword_null)[qi::_val = ph::bind(&Action::make_is_not_null_predicate, &action, qi::_val)]
            );

        // additive_operator = qi::lit("+") | qi::lit("-");
        arithmetic_expression = arithmetic_term[qi::_val = qi::_1] >> *(
                (qi::lit("+") >> arithmetic_term[qi::_val = ph::bind(&Action::make_arithmetic_operator, &action, NodeType::kAdd, qi::_val, qi::_1)]) |
                (qi::lit("-") >> arithmetic_term[qi::_val = ph::bind(&Action::make_arithmetic_operator, &action, NodeType::kSub, qi::_val, qi::_1)])
            );
        // multiplicative_operator = qi::lit("*") | qi::lit("/");
        arithmetic_term = arithmetic_factor[qi::_val = qi::_1] >> *(
                (qi::lit("*") >> arithmetic_factor[qi::_val = ph::bind(&Action::make_arithmetic_operator, &action, NodeType::kMul, qi::_val, qi::_1)]) |
                (qi::lit("/") >> arithmetic_factor[qi::_val = ph::bind(&Action::make_arithmetic_operator, &action, NodeType::kDiv, qi::_val, qi::_1)])
            );
        arithmetic_factor = (operand | qi::lit("(") >> arithmetic_expression >> qi::lit(")"))[qi::_val = qi::_1];

        // operand
        operand = (decimal_value | quoted_string | null_value | attr_value)[qi::_val = qi::_1];
        decimal_value = qi::double_[qi::_val = ph::bind(&Action::make_decimal_operand, &action, qi::_1)];
        quoted_string = qi::as_string[qi::raw[qi::char_('\'') >> *(qi::char_ - '\'') >> qi::char_('\'')]][qi::_val = ph::bind(&Action::make_string_operand, &action, qi::_1)];
        null_value = keyword_null[qi::_val = ph::bind(&Action::make_null_value_operand, &action)];
        attr_value = identifier[qi::_val = ph::bind(&Action::make_attr_value_operand, &action, qi::_1)];

        // TODO alias の定義
        // ⇒ 先頭数字はNG

        // TODO 仮で半角英数小文字
        // lexeme : 単語として認識させる
        identifier = qi::as_string[qi::lexeme[(+qi::alnum)]][qi::_val = qi::_1];

        // keyword 定義
        keyword_all = define_keyword("all");
        keyword_and = define_keyword("and");
        keyword_as = define_keyword("as");
        keyword_is = define_keyword("is");
        keyword_from = define_keyword("from");
        keyword_not = define_keyword("not");
        keyword_null = define_keyword("null");
        keyword_or = define_keyword("or");
        keyword_select = define_keyword("select");

    }

private:
    SqlSemanticAction action;

    using Action = decltype(action);

    // 大文字・小文字を区別しないキーワードの構文ルールを定義する
    Rule define_keyword(const std::string& keyword) {
        return qi::lit("") >> qi::no_case[qi::lit(keyword)];
    }
};


struct PrintVisitor {

    PrintVisitor(uint64_t indent_size = 2) : indent_size(indent_size) {
    }

    // visitor に渡すvariant型の取りうる引数型の関数オペレータを全部実装すること

    void operator()(SyntaxPtr syntax) { 
        // std::cout << "syntax" << std::endl;
        if (auto v = std::dynamic_pointer_cast<EmptyStatement>(syntax)) {
            _print("empty statement");
            return;
        }
        if (auto v = std::dynamic_pointer_cast<SelectStatement>(syntax)) {
            _print("select statement");
            indentation([&]() {
                this->operator()(v->select_list);
            });
            return;
        }
        if (auto v = std::dynamic_pointer_cast<SelectCondition>(syntax)) {
            _print("select condition");
            indentation([&]() {
                this->operator()(v->node);
                if (v->alias.has_value()) {
                    _print("alias : " + v->alias.value());
                }
            });
            return;
        }
        if (auto v = std::dynamic_pointer_cast<SelectAsterisk>(syntax)) {
            _print("select *");
            return;
        }

        if (!syntax) {
            // TODO なぜか nullptr が来る
            // ⇒ 「;」で終わる場合。空の文の場合にSyntaxActionがないのが原因だろう
            _print("null syntax");
        }
        _print("**** unsupported syntax. ****");
    }

    void operator()(const std::vector<SyntaxPtr>& syntax_list) { 
        // std::cout << "syntax_list" << std::endl; 
        for (auto syntax : syntax_list) {
            this->operator()(syntax);
        }
    }

    void operator()(NodePtr node) {
        _print("Node(" + node_name(node->type()) + ")");
        if (auto v = std::dynamic_pointer_cast<BinaryOperationNode>(node)) {
            indentation([&]() {
                this->operator()(v->lhs);
                this->operator()(v->rhs);
            });
            return;
        }
        if (auto v = std::dynamic_pointer_cast<UnaryOperationNode>(node)) {
            indentation([&]() {
                this->operator()(v->child);
            });
            return;
        }
        if (auto v = std::dynamic_pointer_cast<DecimalOperandNode>(node)) {
            indentation([&]() {
                std::stringstream ss;
                ss << "value : " << v->value << ", is_signed : " << v->is_signed << ", scale : " << v->scale;
                _print(ss.str());
            });
            return;
        }
        if (auto v = std::dynamic_pointer_cast<StringOperandNode>(node)) {
            indentation([&]() {
                _print("value : " + v->value);
            });
            return;
        }
        if (auto v = std::dynamic_pointer_cast<NullValueOperandNode>(node)) {
            indentation([&]() {
                _print("null value");
            });
            return;
        }
        if (auto v = std::dynamic_pointer_cast<AttrValueOperandNode>(node)) {
            indentation([&]() {
                _print("attr value : " + v->column_name);
            });
            return;
        }
        if (!node) {
            _print("null node");
        }
        _print("**** unsupported node type. ****");
        
    }
    void operator()(const std::string& value) {
        indentation([&]() {
            _print("std::string : " + value);
        });
    }

    void print(const Variant& v) {
        std::visit(*this, v);
    }

    void _print(const std::string &message) {
        std::string indent(indent_size * depth, ' ');
        std::cout << indent << message << std::endl;
    }

    void indentation(std::function<void()> action) {
        try {
            depth++;
            action();
            depth--;
        } catch (...) {
            depth--;
            throw;
        }
    }

    const uint64_t indent_size;
    uint64_t depth = 0;
};

const std::string test_sql = R"(
select/* constant */1 ;
SELECT 
    1000,2.2,3,4.567
; 
select 3;select -1,*;
/**
 * select 4;
 */ 
select all 5;-- select 6;
select not ((2.2 + 10) * 30 == 20 and 40== 3) and 5 != 3 or 100 = 4, -1.01 ;
select 'abc';
select -1 / 2.2+ 3* 4-5;
select not 'aaa' == 'b bb  ';
select 4 + null;
select 100 is Null xyz; select (4 + 3) is not null;select Id as Aaa, 123 bbb;
select id == null, name != null;
)";


Variant parse(const std::string& value) {

    std::cout << value << std::endl;
    std::cout << "================" << std::endl;

    using Iterator = std::remove_reference<decltype(value)>::type::const_iterator;
    Iterator first = value.begin(), last = value.end();
    CommentGrammer<Iterator> comment_grammer;
    SQLGrammer<Iterator, CommentGrammer<Iterator>> sql_grammer;
    Variant result;
    bool success = qi::phrase_parse(first, last, sql_grammer, comment_grammer, result);
    if (!success || first != last) {
        std::cout << std::string(first, last) << std::endl;
        throw std::runtime_error("parse error.");
    }

    PrintVisitor print_visitor;
    print_visitor.print(result);

    return result;
}


int main() {

    try {
        parse(test_sql);
    } catch(const std::exception & e) {
        std::cerr << e.what() << std::endl;
    }

    return 0;
}