#include <cmath>
#include <fstream>
#include <iostream>
#include <memory>
#include <optional>
#include <string>
#include <type_traits>
#include <variant>
#include <vector>

#include <boost/spirit/include/qi.hpp>
#include <boost/spirit/include/phoenix.hpp>
#include <boost/phoenix/bind.hpp>

namespace util {

template<typename T>
std::vector<T> concat(const std::vector<T> &a, const std::vector<T> &b) {
    std::vector<T> result(a.size() + b.size());
    std::copy(a.begin(), a.end(), result.begin());
    std::copy(b.begin(), b.end(), result.begin() + a.size());
    return result;
}

// 小数点以下の桁数を数える
int count_scale(double num) {
    int count = 0;
  	double v = num;
    while (v != std::floor(v)) {
        v = num * std::pow(10, ++count);
    }
    return count;
}

} // namespace util

namespace sql::ast {

// 構文
struct Syntax {
    virtual ~Syntax() = default;

};

// 文の基底クラス
struct Statement : public Syntax {
    virtual ~Statement() = default;

};

struct EmptyStatement : public Statement {
};

class Node;

struct SelectCondition : public Syntax {

    SelectCondition(const std::shared_ptr<Node> node, const std::optional<std::string> &alias = std::nullopt) : 
        node(node), alias(alias) {
    }
    const std::shared_ptr<Node> node;
    const std::optional<std::string> alias;

};

struct SelectAsterisk : public Syntax {
    SelectAsterisk(const std::optional<std::string> &table_name = std::nullopt) : table_name(table_name) {
    }
    const std::optional<std::string> table_name;
};

struct SelectCause: public Syntax {
    SelectCause(const std::vector<std::shared_ptr<Syntax>> &select_list) : 
        select_list(select_list) {
    }

    const std::vector<std::shared_ptr<Syntax>> select_list;
};


enum class FromItemType {

    kInnerJoin,
    kLeftOuterJoin,
    kRightOuterJoin,
    kFullOuterJoin,
    kCrossJoin,
    kTableReference,

};

std::string from_item_name(FromItemType type) {
    switch (type) {
    case FromItemType::kInnerJoin:
        return "InnerJoin";
    case FromItemType::kLeftOuterJoin:
        return "LeftOuterJoin";
    case FromItemType::kRightOuterJoin:
        return "RightOuterJoin";
    case FromItemType::kFullOuterJoin:
        return "FullOuterJoin";
    case FromItemType::kCrossJoin:
        return "CrossJoin";
    case FromItemType::kTableReference:
        return "TableReference";
    default:
        throw std::runtime_error("invalid from item type : " + std::to_string(int(type)));
    }
}

struct FromItem : public Syntax {
    FromItem(FromItemType type) : type(type) {
    }
    virtual ~FromItem() = default;

    const FromItemType type;
};

struct TableReference : public FromItem {
    TableReference(
        const std::string &table_name,
        const std::optional<std::string> &alias = std::nullopt
    ) : FromItem(FromItemType::kTableReference), table_name(table_name), alias(alias) {
    }

    const std::string table_name;
    const std::optional<std::string> alias;

};

struct JoinItem : public FromItem {
    JoinItem(
        FromItemType type,
        const std::shared_ptr<FromItem> lhs,
        const std::shared_ptr<FromItem> rhs,
        const std::shared_ptr<Node> join_condition = nullptr
    ) : FromItem(type), lhs(lhs), rhs(rhs), join_condition(join_condition) {
    }
    const std::shared_ptr<FromItem> lhs;
    const std::shared_ptr<FromItem> rhs;
    const std::shared_ptr<Node> join_condition;
};

struct FromCause : public Syntax {
    FromCause(const std::shared_ptr<FromItem> from_item) : from_item(from_item) {
    }

    const std::shared_ptr<FromItem> from_item;
};

struct WhereCause : public Syntax {
    WhereCause(const std::shared_ptr<Node> where_condition) : where_condition(where_condition) {
    }

    const std::shared_ptr<Node> where_condition;
};

struct SelectStatement: public Statement {
    SelectStatement(
        const SelectCause& select_cause,
        const std::optional<FromCause> &from_cause = std::nullopt,
        const std::optional<WhereCause> &where_cause = std::nullopt
    ) : select_cause(select_cause), from_cause(from_cause), where_cause(where_cause) {
    }

    const SelectCause select_cause;
    const std::optional<FromCause> from_cause;
    const std::optional<WhereCause> where_cause;
};


enum class NodeType {

    kOr,
    kAnd,
    kNot,

    kIsNull,

    kEquals,
    kLessThan,
    kLessEqual, 
    kGreaterThan,
    kGreaterEqual,

    kAdd,
    kSub,
    kMul,
    kDiv,

    kDecimalValue,
    kStringValue,
    kNullValue,
    kColumn,

};

std::string node_name(NodeType type) {
    switch (type)
    {
    case NodeType::kOr:
        return "OR";
    case NodeType::kAnd:
        return "AND";
    case NodeType::kNot:
        return "NOT";
    case NodeType::kIsNull:
        return "IS_NULL";
    case NodeType::kEquals:
        return "EQ";
    case NodeType::kLessThan:
        return "LT";
    case NodeType::kLessEqual:
        return "LE";
    case NodeType::kGreaterThan:
        return "GT";
    case NodeType::kGreaterEqual:
        return "LE";
    case NodeType::kAdd:
        return "ADD";
    case NodeType::kSub:
        return "SUB";
    case NodeType::kMul:
        return "MUL";
    case NodeType::kDiv:
        return "DIV";
    case NodeType::kDecimalValue:
        return "DECIMAL";
    case NodeType::kStringValue:
        return "STRING";
    case NodeType::kNullValue:
        return "NULL";
    case NodeType::kColumn:
        return "COLUMN";
    default:
        throw std::runtime_error("invalid node type : " + std::to_string(int(type)));
    }
}

struct Node {

    virtual ~Node() = default;

    virtual NodeType type() const = 0;
};

struct ComputationTreeNode : public Node {

    ComputationTreeNode(NodeType type) : _type(type) {
    }
    virtual ~ComputationTreeNode() = default;

    NodeType type() const {
        return _type;
    }

    const NodeType _type;

};

struct UnaryOperationNode : public ComputationTreeNode {
    UnaryOperationNode(NodeType type, std::shared_ptr<Node> child) : 
        ComputationTreeNode(type), child(child) {
    }
    
    virtual ~UnaryOperationNode() = default;

    const std::shared_ptr<Node> child;

};

struct BinaryOperationNode : public ComputationTreeNode {
    BinaryOperationNode(NodeType type, std::shared_ptr<Node> lhs, std::shared_ptr<Node> rhs) :
        ComputationTreeNode(type), lhs(lhs), rhs(rhs) {
    }

    virtual ~BinaryOperationNode() = default;
    const std::shared_ptr<Node> lhs;
    const std::shared_ptr<Node> rhs;
};

struct DecimalOperandNode : public ComputationTreeNode {
    DecimalOperandNode(double value) : 
        ComputationTreeNode(NodeType::kDecimalValue), value(value), is_signed(value < 0), scale(util::count_scale(value)) {
    }
    virtual ~DecimalOperandNode() = default;
    const double value;
    const bool is_signed;
    const uint64_t scale;

};

struct StringOperandNode : public ComputationTreeNode {
    StringOperandNode(const std::string& value) : 
        ComputationTreeNode(NodeType::kStringValue), value(value) {
    }
    virtual ~StringOperandNode() = default;
    const std::string value;
};

struct NullValueOperandNode : public ComputationTreeNode {
    NullValueOperandNode() : ComputationTreeNode(NodeType::kNullValue) {
    };
    virtual ~NullValueOperandNode() = default;
};

struct ColumnOperandNode : public ComputationTreeNode {
    ColumnOperandNode(
        const std::string& column_name,
        const std::optional<std::string> &table_name = std::nullopt
    ) : ComputationTreeNode(NodeType::kColumn), column_name(column_name), table_name(table_name) {
    }
    virtual ~ColumnOperandNode() = default;
    const std::string column_name;
    const std::optional<std::string> table_name;
};

} // sql::ast

//
// boost alias
//

namespace qi = boost::spirit::qi;
namespace ph = boost::phoenix;

using namespace sql::ast;

// sql::ast alias
using SyntaxPtr = std::shared_ptr<sql::ast::Syntax>;
using StatementPtr = std::shared_ptr<sql::ast::Statement>;
using SelectStatementPtr = std::shared_ptr<sql::ast::SelectStatement>;

using NodePtr = std::shared_ptr<sql::ast::Node>;

using Variant = std::variant<
    SyntaxPtr,
    std::vector<SyntaxPtr>,
    NodePtr,
    std::string
>;

template<typename T>
std::shared_ptr<T> cast_syntax_ptr(const Variant& a) {
    return std::static_pointer_cast<T>(std::get<SyntaxPtr>(a));
}

class SqlSemanticAction {
public:
    SqlSemanticAction() = default;
    virtual ~SqlSemanticAction() = default;

    SyntaxPtr make_empty_statement() {
        static auto empty_stmt = std::make_shared<EmptyStatement>();
        return empty_stmt;
    }

    std::vector<SyntaxPtr> make_syntax_as_list(const Variant& a) {
        if (auto v = std::get_if<SyntaxPtr>(&a)) {
            return std::vector<SyntaxPtr>{*v};
        } else if (auto v = std::get_if<std::vector<SyntaxPtr>>(&a)) {
            return *v;
        }
        return std::vector<SyntaxPtr>{};
    }

    std::vector<SyntaxPtr> make_syntax_list(const Variant& a, const Variant &b) {
        return util::concat(make_syntax_as_list(a), make_syntax_as_list(b));
    }

    SyntaxPtr make_select_statement(
        const Variant& select, 
        const boost::optional<Variant> &from, 
        const boost::optional<Variant> &where
    ) {
        return std::make_shared<SelectStatement>(
            *cast_syntax_ptr<SelectCause>(select),
            from ? std::make_optional(*cast_syntax_ptr<FromCause>(*from)) : std::nullopt, 
            where ? std::make_optional(*cast_syntax_ptr<WhereCause>(*where)) : std::nullopt
        );
    }

    SyntaxPtr make_select_cause(const Variant& a) {
        return std::make_shared<SelectCause>(std::get<std::vector<SyntaxPtr>>(a));
    }

    SyntaxPtr make_select_condition(const Variant& cond, const boost::optional<Variant>& alias) {
        return std::make_shared<SelectCondition>(
            std::get<NodePtr>(cond), 
            alias ? std::make_optional(std::get<std::string>(*alias)) : std::nullopt
        );
    }

    SyntaxPtr make_select_asterisk(const boost::optional<Variant>& table_name) {
        return std::make_shared<SelectAsterisk>(
            table_name ? std::make_optional(std::get<std::string>(*table_name)) : std::nullopt
        );
    }

    SyntaxPtr make_table_reference(const Variant& name, const boost::optional<Variant>& alias) {
        return std::make_shared<TableReference>(
            std::get<std::string>(name), 
            alias ? std::make_optional(std::get<std::string>(*alias)) : std::nullopt
        );
    }

    SyntaxPtr make_conditional_join_item(
        FromItemType type, const Variant& lhs_from_item, const Variant& rhs_from_item, const Variant& node
    ) {
        return std::make_shared<JoinItem>(
            type,
            cast_syntax_ptr<FromItem>(lhs_from_item),
            cast_syntax_ptr<FromItem>(rhs_from_item),
            std::get<NodePtr>(node)
        );
    }

    SyntaxPtr make_cross_join_item(const Variant& lhs_from_item, const Variant& rhs_from_item) {
        return std::make_shared<JoinItem>(
            FromItemType::kCrossJoin,
            cast_syntax_ptr<FromItem>(lhs_from_item),
            cast_syntax_ptr<FromItem>(rhs_from_item)
        );
    }

    SyntaxPtr make_from_cause(const Variant& from_item) {
        return std::make_shared<FromCause>(
            cast_syntax_ptr<FromItem>(from_item)
        );
    }

    SyntaxPtr make_where_cause(const Variant& node) {
        return std::make_shared<WhereCause>(std::get<NodePtr>(node));
    }

    NodePtr make_unary_operator(NodeType type, const Variant& child) {
        return std::make_shared<UnaryOperationNode>(type, std::get<NodePtr>(child));
    }

    NodePtr make_binary_operator(NodeType type, const Variant& lhs, const Variant &rhs) {
        return std::make_shared<BinaryOperationNode>(type, std::get<NodePtr>(lhs), std::get<NodePtr>(rhs));
    }

    NodePtr make_or_operator(const Variant& lhs, const Variant &rhs) {
        return make_binary_operator(NodeType::kOr, lhs, rhs);
    }

    NodePtr make_and_operator(const Variant& lhs, const Variant &rhs) {
        return make_binary_operator(NodeType::kAnd, lhs, rhs);
    }

    NodePtr make_not_operator(const Variant& child) {
        return make_unary_operator(NodeType::kNot, child);
    }

    NodePtr make_is_null_predicate(const Variant& child) {
        return make_unary_operator(NodeType::kIsNull, child);
    }

    NodePtr make_is_not_null_predicate(const Variant& child) {
        return make_not_operator(make_is_null_predicate(child));
    }
    
    NodePtr make_comparison_operator(NodeType type, const Variant& lhs, const Variant &rhs) {
        if (type == NodeType::kEquals) {
            if (std::get<NodePtr>(rhs)->type() == NodeType::kNullValue) {
                // 等号比較で右辺がNULLの場合、IS NULL ノードとする。
                return make_is_null_predicate(lhs);
            }
        }
        return make_binary_operator(type, lhs, rhs);
    }

    NodePtr make_not_euality_operator(const Variant& lhs, const Variant &rhs) {
        return make_not_operator(make_comparison_operator(NodeType::kEquals, lhs, rhs));
    }

    NodePtr make_arithmetic_operator(NodeType type, const Variant& lhs, const Variant &rhs) {
        return make_binary_operator(type, lhs, rhs);
    }

    NodePtr make_decimal_operand(double v) {
        return std::make_shared<DecimalOperandNode>(v);
    }

    NodePtr make_string_operand(const std::string &v) {
        return std::make_shared<StringOperandNode>(v);
    }

    NodePtr make_null_value_operand() {
        static auto null_value = std::make_shared<NullValueOperandNode>();
        return null_value;
    }

    NodePtr make_column_operand(const Variant &column_name, const boost::optional<Variant> &table_name) {
        return std::make_shared<ColumnOperandNode>(
            std::get<std::string>(column_name), 
            table_name ? std::make_optional(std::get<std::string>(*table_name)) : std::nullopt
        );
    }

};


template<typename Iterator>
struct CommentGrammer : public qi::grammar<Iterator> {
public : 

    // 参考
    // https://oki-miyuki.github.io/boost_spirit_guide/skipper.html

    using Rule = qi::rule<Iterator>;

    CommentGrammer() : CommentGrammer::base_type(comment) {
        comment = qi::standard::space | inline_comment | multiline_comment;
        multiline_comment = qi::lit("/*") >> *(qi::standard::char_ - qi::lit("*/") - qi::eoi) >> qi::lit("*/");
        inline_comment = qi::lit("--") >> *(qi::standard::char_ - qi::eol -qi::eoi) >> (qi::eol | qi::eoi);
    }
private :
    Rule comment;
    Rule inline_comment;
    Rule multiline_comment;
};


template<typename Iterator, typename Skipper>
class SQLGrammer : public qi::grammar<Iterator, Variant(), Skipper> {

    // https://github.com/oki-miyuki/boost_spirit_guide/

    using Rule = qi::rule<Iterator, Variant(), Skipper>;

    Rule statement_list;
    Rule statement;
    Rule empty_statement;
    Rule select_statement;
    Rule select_cause;
    Rule select_list;
    Rule select_element;
    Rule select_condition;

    Rule from_cause;
    Rule from_item_list;
    Rule from_item;

    Rule table_reference;

    Rule where_cause;

    // expression
    Rule logical_expression;
    Rule logical_term;
    Rule logical_factor;
    Rule logical_factor_with_not;
    Rule logical_factor_without_not;
    // Rule comparison_operator;
    Rule comparison_expression;

    // Rule additive_operator;
    // Rule multiplicative_operator;
    Rule arithmetic_expression;
    Rule arithmetic_term;
    Rule arithmetic_factor;

    // operand
    Rule operand;
    Rule decimal_value;
    Rule string_value;
    Rule null_value;
    Rule column;

    Rule identifier;

    // token
    Rule keywords;
    Rule keyword_all;
    Rule keyword_and;
    Rule keyword_as;
    Rule keyword_cross;
    Rule keyword_from;
    Rule keyword_inner;
    Rule keyword_is;
    Rule keyword_join;
    Rule keyword_not;
    Rule keyword_null;
    Rule keyword_on;
    Rule keyword_or;
    Rule keyword_outer;
    Rule keyword_select;
    Rule keyword_where;

public:
    SQLGrammer() : SQLGrammer::base_type(statement_list) {

        statement_list = 
            statement[qi::_val = ph::bind(&Action::make_syntax_as_list, &action, qi::_1)]
                >> *(qi::lit(";") >> statement[qi::_val = ph::bind(&Action::make_syntax_list, &action, qi::_val, qi::_1)]);

        statement = (select_statement | empty_statement)[qi::_val = qi::_1];
        
        empty_statement = qi::lit("")[qi::_val = ph::bind(&Action::make_empty_statement, &action)];

        select_statement = (select_cause >> -from_cause >> -where_cause)[qi::_val = ph::bind(&Action::make_select_statement, &action, qi::_1, qi::_2, qi::_3)];

        select_cause = 
            keyword_select >> -(keyword_all) >> select_list[qi::_val = ph::bind(&Action::make_select_cause, &action, qi::_1)];

        select_list = 
            select_element[qi::_val = ph::bind(&Action::make_syntax_as_list, &action, qi::_1)] 
                >> *(qi::lit(",") >> select_element[qi::_val = ph::bind(&Action::make_syntax_list, &action, qi::_val, qi::_1)]);

        select_element = 
              select_condition[qi::_val = qi::_1] 
            | (-(identifier >> qi::lit(".")) >> qi::lit("*"))[qi::_val = ph::bind(&Action::make_select_asterisk, &action, qi::_1)];

        select_condition = 
            ((logical_expression | arithmetic_expression) >> -(qi::omit[-(keyword_as)] >> identifier))[qi::_val = ph::bind(&Action::make_select_condition, &action, qi::_1, qi::_2)];

        from_cause = keyword_from >> from_item_list[qi::_val = ph::bind(&Action::make_from_cause, &action, qi::_1)];
        from_item_list = from_item[qi::_val = qi::_1]
            >> *(qi::lit(",") >> from_item[qi::_val = ph::bind(&Action::make_cross_join_item, &action, qi::_val, qi::_1)]);

        from_item = table_reference[qi::_val = qi::_1] 
            >> *(
                (qi::omit[-(keyword_inner)] >> qi::omit[keyword_join] >> table_reference >> qi::omit[keyword_on] >> logical_expression)[qi::_val = ph::bind(&Action::make_conditional_join_item, &action, FromItemType::kInnerJoin, qi::_val, qi::_1, qi::_2)]
            );

        table_reference = (identifier >> -(qi::omit[-(keyword_as)] >> identifier))[qi::_val = ph::bind(&Action::make_table_reference, &action, qi::_1, qi::_2)];

        where_cause = keyword_where >> logical_expression[qi::_val = ph::bind(&Action::make_where_cause, &action, qi::_1)];

        // 式
        logical_expression = 
            logical_term[qi::_val = qi::_1] 
                >> *(keyword_or >> logical_term[qi::_val = ph::bind(&Action::make_or_operator, &action, qi::_val, qi::_1)]);

        logical_term = 
            logical_factor[qi::_val = qi::_1] 
                >> *(keyword_and >> logical_factor[qi::_val = ph::bind(&Action::make_and_operator, &action, qi::_val, qi::_1)]);
        
        logical_factor_without_not = (comparison_expression | qi::lit("(") >> logical_expression >> qi::lit(")"))[qi::_val = qi::_1];
        logical_factor_with_not = keyword_not >> logical_factor_without_not[qi::_val = ph::bind(&Action::make_not_operator, &action, qi::_1)];
        // notあり⇒ not なしの順にすること
        logical_factor = (logical_factor_with_not | logical_factor_without_not)[qi::_val = qi::_1];

        // comparison_operator = qi::lit("==") | qi::lit("=") | qi::lit("<>") | qi::lit("!=") | qi::lit("<=") | qi::lit("<") | qi::lit(">=")  | qi::lit(">");
        comparison_expression = arithmetic_expression[qi::_val = qi::_1] 
            >> (
                  ((qi::lit("==") | qi::lit("=")) >> arithmetic_expression[qi::_val = ph::bind(&Action::make_comparison_operator, &action, NodeType::kEquals, qi::_val, qi::_1)])
                | ((qi::lit("<>") | qi::lit("!=")) >> arithmetic_expression[qi::_val = ph::bind(&Action::make_not_euality_operator, &action, qi::_val, qi::_1)])
                | (qi::lit("<=") >> arithmetic_expression[qi::_val = ph::bind(&Action::make_comparison_operator, &action, NodeType::kLessEqual, qi::_val, qi::_1)])
                | (qi::lit("<") >> arithmetic_expression[qi::_val = ph::bind(&Action::make_comparison_operator, &action, NodeType::kLessThan, qi::_val, qi::_1)])
                | (qi::lit(">=") >> arithmetic_expression[qi::_val = ph::bind(&Action::make_comparison_operator, &action, NodeType::kGreaterEqual, qi::_val, qi::_1)])
                | (qi::lit(">") >> arithmetic_expression[qi::_val = ph::bind(&Action::make_comparison_operator, &action, NodeType::kGreaterThan, qi::_val, qi::_1)])
                | (keyword_is >> keyword_null)[qi::_val = ph::bind(&Action::make_is_null_predicate, &action, qi::_val)]
                | (keyword_is >> keyword_not >> keyword_null)[qi::_val = ph::bind(&Action::make_is_not_null_predicate, &action, qi::_val)]
            );

        // additive_operator = qi::lit("+") | qi::lit("-");
        arithmetic_expression = arithmetic_term[qi::_val = qi::_1] 
            >> *(
                  (qi::lit("+") >> arithmetic_term[qi::_val = ph::bind(&Action::make_arithmetic_operator, &action, NodeType::kAdd, qi::_val, qi::_1)])
                | (qi::lit("-") >> arithmetic_term[qi::_val = ph::bind(&Action::make_arithmetic_operator, &action, NodeType::kSub, qi::_val, qi::_1)])
            );
        // multiplicative_operator = qi::lit("*") | qi::lit("/");
        arithmetic_term = arithmetic_factor[qi::_val = qi::_1] 
            >> *(
                  (qi::lit("*") >> arithmetic_factor[qi::_val = ph::bind(&Action::make_arithmetic_operator, &action, NodeType::kMul, qi::_val, qi::_1)])
                | (qi::lit("/") >> arithmetic_factor[qi::_val = ph::bind(&Action::make_arithmetic_operator, &action, NodeType::kDiv, qi::_val, qi::_1)])
            );
        arithmetic_factor = (operand | qi::lit("(") >> arithmetic_expression >> qi::lit(")"))[qi::_val = qi::_1];

        // operand
        operand = (decimal_value | string_value | null_value | column)[qi::_val = qi::_1];
        decimal_value = qi::double_[qi::_val = ph::bind(&Action::make_decimal_operand, &action, qi::_1)];
        string_value = qi::lit('\'') >> qi::as_string[qi::lexeme[*((qi::lit('\\') >> qi::char_('\\')) | (qi::lit('\\') >> qi::char_('\'')) | (qi::char_ - qi::char_('\'')))]][qi::_val = ph::bind(&Action::make_string_operand, &action, qi::_1)] >> qi::lit('\'');
        null_value = keyword_null[qi::_val = ph::bind(&Action::make_null_value_operand, &action)];

        // TODO カラム名の定義は現状SQLライク
        column = (-(identifier >> qi::lit(".")) >> identifier)[qi::_val = ph::bind(&Action::make_column_operand, &action, qi::_2, qi::_1)];

        // TODO 仮で半角英数小文字 
        // ⇒ 先頭数字はNG, キーワードは除く（解析に失敗するため）
        // ⇒ キーワード含むものは「"」囲う等の対応が必要
        // lexeme : 単語として認識させる
        identifier = (qi::as_string[qi::lexeme[(+qi::alnum)]] - keywords)[qi::_val = qi::_1];

        // keyword 定義
        keywords = (
              keyword_all
            | keyword_and
            | keyword_as
            | keyword_cross
            | keyword_from
            | keyword_inner
            | keyword_is
            | keyword_join
            | keyword_not
            | keyword_null
            | keyword_on
            | keyword_or
            | keyword_outer
            | keyword_select
            | keyword_where
        );

        keyword_all = define_keyword("all");
        keyword_and = define_keyword("and");
        keyword_as = define_keyword("as");
        keyword_cross = define_keyword("cross");
        keyword_from = define_keyword("from");
        keyword_inner = define_keyword("inner");
        keyword_is = define_keyword("is");
        keyword_join = define_keyword("join");
        keyword_not = define_keyword("not");
        keyword_null = define_keyword("null");
        keyword_on = define_keyword("on");
        keyword_or = define_keyword("or");
        keyword_outer = define_keyword("outer");
        keyword_select = define_keyword("select");
        keyword_where =  define_keyword("where");
    }

private:
    SqlSemanticAction action;

    using Action = decltype(action);

    // 大文字・小文字を区別しないキーワードの構文ルールを定義する
    Rule define_keyword(const std::string& keyword) {
        return qi::lit("") >> qi::no_case[qi::lit(keyword)];
    }
};

// 動作確認用
struct PrintVisitor {

    PrintVisitor(uint64_t indent_size = 2) : indent_size(indent_size) {
    }

    // visitor に渡すvariant型の取りうる引数型の関数オペレータを全部実装すること

    void operator()(SyntaxPtr syntax) { 
        // std::cout << "syntax" << std::endl;
        if (auto v = std::dynamic_pointer_cast<EmptyStatement>(syntax)) {
            _print("empty statement");
            return;
        }
        if (auto v = std::dynamic_pointer_cast<SelectStatement>(syntax)) {
            _print("select statement");
            indentation([&]() {
                this->operator()(v->select_cause.select_list);
            });
            if (v->from_cause) {
                indentation([&]() {
                    _print("from");
                    indentation([&]() {
                        this->operator()((*v->from_cause).from_item);
                    });
                });
            }
            if (v->where_cause) {
                indentation([&]() {
                    _print("where");
                    indentation([&]() {
                        this->operator()((*v->where_cause).where_condition);
                    });
                });
            }
            return;
        }
        if (auto v = std::dynamic_pointer_cast<SelectCondition>(syntax)) {
            _print("select condition");
            indentation([&]() {
                this->operator()(v->node);
                if (v->alias) {
                    _print("alias : " + *v->alias);
                }
            });
            return;
        }
        if (auto v = std::dynamic_pointer_cast<SelectAsterisk>(syntax)) {
            std::stringstream ss;
            ss << "select ";
            if (v->table_name) {
                ss << *v->table_name << ".";
            }
            ss << "*";
            _print(ss.str());
            return;
        }
        if (auto v = std::dynamic_pointer_cast<TableReference>(syntax)) {
            std::stringstream ss;
            ss << "table_name : " << v->table_name;
            if (v->alias) {
                ss << ", alias : " << *v->alias;
            }
            _print(ss.str());
            return;
        }
        if (auto v = std::dynamic_pointer_cast<JoinItem>(syntax)) {
            _print("FromItem(" + from_item_name(v->type) + ")");
            indentation([&]() {
                this->operator()(v->lhs);
                this->operator()(v->rhs);
            });
            if (v->join_condition) {
                indentation([&]() {
                    this->operator()(v->join_condition);
                });
            }
            return;
        }

        if (!syntax) {
            _print("null syntax");
            return;
        }
        _print("**** unsupported syntax. ****");
    }

    void operator()(const std::vector<SyntaxPtr>& syntax_list) { 
        for (auto syntax : syntax_list) {
            this->operator()(syntax);
        }
    }

    void operator()(NodePtr node) {
        _print("Node(" + node_name(node->type()) + ")");
        if (auto v = std::dynamic_pointer_cast<BinaryOperationNode>(node)) {
            indentation([&]() {
                this->operator()(v->lhs);
                this->operator()(v->rhs);
            });
            return;
        }
        if (auto v = std::dynamic_pointer_cast<UnaryOperationNode>(node)) {
            indentation([&]() {
                this->operator()(v->child);
            });
            return;
        }
        if (auto v = std::dynamic_pointer_cast<DecimalOperandNode>(node)) {
            indentation([&]() {
                std::stringstream ss;
                ss << "value : " << v->value << ", is_signed : " << v->is_signed << ", scale : " << v->scale;
                _print(ss.str());
            });
            return;
        }
        if (auto v = std::dynamic_pointer_cast<StringOperandNode>(node)) {
            indentation([&]() {
                std::stringstream ss;
                ss << "value : '" << v->value << "'";
                _print(ss.str());
            });
            return;
        }
        if (auto v = std::dynamic_pointer_cast<NullValueOperandNode>(node)) {
            indentation([&]() {
                _print("null value");
            });
            return;
        }
        if (auto v = std::dynamic_pointer_cast<ColumnOperandNode>(node)) {
            indentation([&]() {
                std::stringstream ss;
                ss << "column_name : " + v->column_name;
                if (v->table_name) {
                    ss << ", table_name : " << *v->table_name;
                }
                _print(ss.str());
            });
            return;
        }
        if (!node) {
            _print("null node");
        }
        _print("**** unsupported node type. ****");
        
    }
    void operator()(const std::string& value) {
        indentation([&]() {
            _print("std::string : " + value);
        });
    }

    void print(const Variant& v) {
        std::visit(*this, v);
    }

    void _print(const std::string &message) {
        std::string indent(indent_size * depth, ' ');
        std::cout << indent << message << std::endl;
    }

    void indentation(std::function<void()> action) {
        try {
            depth++;
            action();
            depth--;
        } catch (...) {
            depth--;
            throw;
        }
    }

    const uint64_t indent_size;
    uint64_t depth = 0;
};


void parse(const std::string& value) {

    std::cout << value << std::endl;
    std::cout << "================" << std::endl;

    using Iterator = std::remove_reference<decltype(value)>::type::const_iterator;
    Iterator first = value.begin(), last = value.end();
    CommentGrammer<Iterator> comment_grammer;
    SQLGrammer<Iterator, CommentGrammer<Iterator>> sql_grammer;
    Variant result;
    bool success = false;
    std::string error_message = "parse error.";
    try {
        success = qi::phrase_parse(first, last, sql_grammer, comment_grammer, result);
    } catch (const std::exception& e) {
        success = false;
        error_message = e.what();
    }
    if (!success || first != last) {
        const auto nrow = std::accumulate(value.begin(), first, int(1), [](int nrow, char a) {
            return nrow + int(a == '\n');
        });
        std::stringstream ss;
        ss << error_message << " line : " << nrow << ", " <<  std::string(first, last) << std::endl;
        throw std::runtime_error(ss.str());
    }

    PrintVisitor print_visitor;
    print_visitor.print(result);

}

std::string read_text(const std::string& path) {
    std::ifstream file(path);
    if (!file) {
        throw std::runtime_error("file not found. path : " + path);
    }

    std::stringstream ss;
    std::string line;
    while (std::getline(file, line)) {
        ss << line << std::endl;
    }
    return ss.str();
}

int main(int argc, char *argv[]) {

    argc--;
    argv++;

    std::string file_name;

    try {
        if (argc < 1) {
            throw std::invalid_argument("invalid argument.");
        }

        file_name = argv[0];
        const auto sql_str = read_text(file_name);

        parse(sql_str);
    } catch(const std::exception & e) {
        std::cerr << file_name << " : " << e.what() << std::endl;
        return 1;
    }

    return 0;
}