select/* constant */1 ;
SELECT 
    1000,2.2,3,4.567
; 
select 3;select -1,*;
/**
 * select 4;
 */ 
select all +5;-- select 6;
select not ((2.2 + 10) * 30 == 20 and 40== 3) and 5 != 3 or 100 = 4, -1.01 ;
select 'abc';
select -1 / 2.2+ 3* 4-5;
select not 'aaa' == 'b bb  aaああ  ';
select 4 + null;
select 100 is Null xyz; select (4 + 3) is not null;select Id as Aaa, 123 bbb;
select a.id == null, name != null;
select abc as a, def b from foobar as f; select id, name FROM bar as b;
select * from FooBar as fb where fb.id = 100 and name = 'john';
select test.* from test a, test b, foo;
select * from foo a join bar on a.id = bar.id, test2 as t;;;;
select id, name from test3 as TEST_3-3 where name ='x\\x\\x\'';
select "select" as "as" from "fromテーブル";