Boost.Spirit.Qiで「0回または1回 A にマッチする」場合のセマンティックアクションを書くには、`qi::optional`を使用します。以下に具体例を示します。

```cpp
#include <boost/spirit/include/qi.hpp>
#include <string>
#include <iostream>

namespace qi = boost::spirit::qi;

template <typename Iterator>
struct MyGrammar : qi::grammar<Iterator, std::string()>
{
    MyGrammar() : MyGrammar::base_type(start)
    {
        using qi::char_;
        using qi::lit;
        using qi::optional;

        start = (optional[char_('A')])[&MyGrammar::action];
    }

    static void action(const boost::optional<char>& opt)
    {
        if (opt)
            std::cout << "Matched: " << *opt << std::endl;
        else
            std::cout << "No match" << std::endl;
    }

    qi::rule<Iterator, std::string()> start;
};

int main()
{
    std::string input = "A";
    std::string::const_iterator iter = input.begin();
    std::string::const_iterator end = input.end();
    MyGrammar<std::string::const_iterator> grammar;

    bool r = qi::parse(iter, end, grammar);

    if (r && iter == end)
    {
        std::cout << "Parsing succeeded\n";
    }
    else
    {
        std::cout << "Parsing failed\n";
    }

    return 0;
}
```

この例では、`qi::optional`を使用して「0回または1回 A にマッチする」パーサーを定義しています。セマンティックアクションは`action`関数内で定義されており、マッチした場合としなかった場合の処理を行います。

何か他に質問がありますか？

ソース: Copilot との会話、 2024/8/26
(1) Boost Spirit V2のSpirit.Qiについて少し調べた #Spirit.V2 - Qiita. https://qiita.com/Ruo_Ando/items/f7c5ba8fa0bce3aa152d.
(2) boost::spirit::qiを使って構文解析する - Panda Noir. https://www.pandanoir.info/entry/2017/12/21/190000.
(3) boost::spirit::qi を触ってみる - Nosの日記. https://nos.hateblo.jp/entry/20140221/1393003137.
(4) Boost.Qiのqi::skip_flag::dont_postskipを追求する #qi - Qiita. https://qiita.com/Ruo_Ando/items/3fbccef9a1c4b56281dc.