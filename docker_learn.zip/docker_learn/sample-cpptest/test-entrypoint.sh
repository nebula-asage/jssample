#!/bin/bash

set -e

# entrypoint はbuild & run

cd ${WORKDIR}

if [ -e main.cpp ] ;then 
    g++ --std=c++11 -I/usr/local/include main.cpp
    ./a.out "$@"
fi

cd ../