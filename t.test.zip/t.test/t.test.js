var ttest = (function() {

    function add(a, b) {
        return a + b;
    }

    function sum(a) {
        return a.reduce(add);
    }

    function mean(a) {
        var length = a.length;
        return sum(a) / length;
    }

    function uvar(a) {
        var length = a.length;
        var m = mean(a);
        return a.reduce(function(p, c) {
            return p + Math.pow(c - m, 2);
        }, 0) / (length - 1);
    }

    function pt(t, df) {
        return jStat.studentt.cdf(t, df);
    }

    function qt(t, df) {
        return jStat.studentt.inv(t, df);
    }

    function ttest(g1, g2, confLevel) {
        confLevel = confLevel || 0.95;

        var n1 = g1.length;
        var n2 = g2.length;
        var m1 = mean(g1);
        var m2 = mean(g2);
        var u1 = uvar(g1);
        var u2 = uvar(g2);
        
        var df = n1 + n2 - 2;
        var v = 0;
        if (n1 > 1) {
            v = v + (n1 - 1) * u1;
        }
        if (n2 > 1){
            v = v + (n2 - 1) * u2;
        }
        v = v / df;
        var stderr = Math.sqrt(v * (1 / n1 + 1 / n1));
        var tstat = (m1 - m2) / stderr;
        
        var pval = 2 * pt(-Math.abs(tstat), df);
        var alpha = 1 - confLevel;
        var cint = qt(1 - alpha / 2, df);
        
        cint = [-cint, cint].map(function(e) {
            return (e + tstat) * stderr;
        });
        
        //return(list("t"=tstat, "p"=pval, "df"=df, "cint"=cint,  "mean1"=m1, "mean2"=m2))
        return {
            t :tstat,
            df : df,
            p : pval,
            mean1 : m1,
            mean2 : m2,
            cint : {
                lower : cint[0],
                upper : cint[1]
            }
        };
    }
    function foo() {
        var g1 = [2,0,3,-3,4,1,-1,4];
        var g2 = [5,-1,2,-1,7,3,4,5];
        ttest(g1, g2);
    }

    return ttest;
})();