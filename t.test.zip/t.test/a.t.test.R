

g1 <- c(2,0,3,-3,4,1,-1,4)
g2 <- c(5,-1,2,-1,7,3,4,5)
r <- t.test(x=g1, y=g2, var.equal = T)
print(r)

a.t.test <- function(g1, g2, conf.level=0.95) {
  n1 <- length(g1)
  n2 <- length(g2)
  m1 <- mean(g1)
  m2 <- mean(g2)
  u1 <- var(g1)
  u2 <- var(g2)
  
  df <- n1 + n2 - 2
  v <- 0
  if (n1 > 1)
    v <- v + (n1 - 1) * u1
  if (n2 > 1)
    v <- v + (n2 - 1) * u2
  v <- v / df
  stderr <- sqrt(v * (1 / n1 + 1 / n1))
  tstat <- (m1 - m2) / stderr
  
  pval <- 2 * pt(-abs(tstat), df)
  alpha <- 1 - conf.level
  cint <- qt(1 - alpha / 2, df)
  # print(cint)
  cint <- tstat + c(-cint, cint)
  cint <- cint * stderr
  
  return(list("t"=tstat, "p"=pval, "df"=df, "cint"=cint,  "mean1"=m1, "mean2"=m2))
  # pt -> 
  # jStat.studentt.cdf(-1.2999,14) * 2
  
  # cint
  # jStat.studentt.inv(1-(0.05 / 2),14)
  
  # https://www.quora.com/In-R-what-is-the-difference-between-dt-pt-and-qt-in-reference-to-the-student-t-distribution
  
}

