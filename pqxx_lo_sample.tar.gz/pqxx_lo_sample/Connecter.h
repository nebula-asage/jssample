#pragma once
#include <string>
#include <sstream>
#include <memory>
#include <mutex>
#include <unordered_map>
#include <algorithm>
#include <libpq-fe.h>
#include <libpq/libpq-fs.h>

using OID = int64_t;

class ResultSet {
    using PGResultSetPtr = std::unique_ptr<PGresult, decltype(&PQclear)>;

public :
    ResultSet(PGresult *res) : _raw(
        PGResultSetPtr(res, PQclear)
    ) {
    }
    int get_record_length() {
        return PQntuples(_raw.get());
    }

    template<typename T>
    T get_value_as(int row, int col) {
        T val;
        std::istringstream ss(get_value(row, col));
        ss >> val;
        return val;
    }

    std::string get_value(int row, int col) {
        return std::string(PQgetvalue(_raw.get(), row, col));
    }

    bool is_null(int row, int col) {
        return PQgetisnull(_raw.get(), row, col) == 1;
    }

    bool is_error() {
        switch(get_result_status()) {
            case PGRES_EMPTY_QUERY :
            case PGRES_COMMAND_OK : 
            case PGRES_TUPLES_OK :
                return false;
            default : {
                return true;
            }
        }
    }

    ExecStatusType get_result_status() {
        return PQresultStatus(_raw.get());
    }

private :
    PGResultSetPtr _raw;

};

class Connecter {
    
    using PGconnPtr = std::unique_ptr<PGconn, decltype(&PQfinish)>;
public : 

    Connecter(const std::string &conn_info) : _raw(
        PGconnPtr(PQconnectdb(conn_info.c_str()), PQfinish)
    ) {
        if (PQstatus(_raw.get()) != CONNECTION_OK) {
            throw std::runtime_error("connection faild.");
        }
        load_fn_oids();
        std::cout << "connection success." << std::endl;
    }

    std::shared_ptr<ResultSet> execute(const std::string &sql) {
        auto res = std::make_shared<ResultSet>(
            PQexec(_raw.get(), sql.c_str())
        );
        if (res->is_error()) {
            throw std::runtime_error("sql error. " + get_error_message());  
        }
        return res;
    }

    void begin(const std::string& txid = "default") {
        execute("BEGIN");
        _txid = txid;
    }

    void commit() {
        execute("COMMIT");
        _txid.clear();
    }

    void prepare_tx() {
        execute("PREPARE TRANSACTION '" + _txid + "'");
    }

    void commit_prepared() {
        execute("COMMIT PREPARED '" + _txid + "'");
        _txid.clear();
    }

    void rollback() {
        if (_txid.empty()) {
            return;
        }
        execute("ROLLBACK");
        _txid.clear();
    }

    void rollback_prepared() {
        if (_txid.empty()) {
            return;
        }
        execute("ROLLBACK PREPARED '" + _txid + "'");
        _txid.clear();
    }

    PGconn* get_raw() {
        return _raw.get();
    }

    std::string get_error_message() {
        return std::string(PQerrorMessage(_raw.get()));
    }

    OID get_fn_oid(const std::string& fn_name) {
        return _fn_oids.at(fn_name);
    }
private :
    std::string _txid;
    PGconnPtr _raw;

    static bool _is_init;
    static std::unordered_map<std::string, OID> _fn_oids;

    std::mutex _mtx;
    void load_fn_oids() {
        std::unique_lock<decltype(_mtx)> lock(_mtx);
        if (_is_init) {
            return;
        }
        size_t i = 0;
        std::stringstream ss;
        ss << "SELECT proname, oid FROM pg_catalog.pg_proc WHERE proname IN (";
        std::for_each(_fn_oids.begin(), _fn_oids.end(), [&](const decltype(_fn_oids)::value_type& pair) {
            if (i != 0) {
                ss << ",";
            }
            ss << "'" << pair.first << "'";
            i++;
        });
        ss << ")";

        auto res = execute(ss.str());
        const auto record_length = res->get_record_length();
        for (int i = 0; i < record_length; ++i) {
            const auto fname = res->get_value(i, 0);
            auto itr = _fn_oids.find(fname);
            if (itr != _fn_oids.end()) {
                itr->second = res->get_value_as<OID>(i, 1);
                std::cout << fname << " oid : " << itr->second << std::endl;
                continue;
            }
        }
        std::for_each(_fn_oids.begin(), _fn_oids.end(), [&](const decltype(_fn_oids)::value_type& pair) {
            auto oid = _fn_oids.at(pair.first);
            if (oid == 0) {
                throw std::runtime_error("user function " + pair.first + "'s OID not found.");    
            }
        });
        _is_init = true;
    }
};

std::unordered_map<std::string, OID> Connecter::_fn_oids = {
    {"add_one", 0},
    {"lo_write_by_offsets", 0}
};
bool Connecter::_is_init = false;
