#pragma once
#include <string>
#include <sstream>
#include <memory>
#include <libpq-fe.h>
#include <libpq/libpq-fs.h>

using OID = int64_t;

class ResultSet {
    using PGResultSetPtr = std::unique_ptr<PGresult, decltype(&PQclear)>;

public :
    ResultSet(PGresult *res) : _raw(
        PGResultSetPtr(res, PQclear)
    ) {
    }
    int get_record_length() {
        return PQntuples(_raw.get());
    }

    template<typename T>
    T get_value_as(int row, int col) {
        T val;
        std::istringstream ss(get_value(row, col));
        ss >> val;
        return val;
    }

    std::string get_value(int row, int col) {
        return std::string(PQgetvalue(_raw.get(), row, col));
    }

    bool is_null(int row, int col) {
        return PQgetisnull(_raw.get(), row, col) == 1;
    }

    bool is_error() {
        switch(get_result_status()) {
            case PGRES_EMPTY_QUERY :
            case PGRES_COMMAND_OK : 
            case PGRES_TUPLES_OK :
                return false;
            default : {
                return true;
            }
        }
    }

    ExecStatusType get_result_status() {
        return PQresultStatus(_raw.get());
    }

private :
    PGResultSetPtr _raw;

};

class Connecter {
    
    using PGconnPtr = std::unique_ptr<PGconn, decltype(&PQfinish)>;
public : 

    Connecter(const std::string &conn_info) : _raw(
        PGconnPtr(PQconnectdb(conn_info.c_str()), PQfinish)
    ) {
        if (PQstatus(_raw.get()) != CONNECTION_OK) {
            throw std::runtime_error("connection faild.");
        }
        std::cout << "connection success." << std::endl;
    }

    std::shared_ptr<ResultSet> execute(const std::string &sql) {
        auto res = PQexec(_raw.get(), sql.c_str());

        switch(PQresultStatus(res)) {
            case PGRES_EMPTY_QUERY :
            case PGRES_COMMAND_OK : 
            case PGRES_TUPLES_OK :
                return std::make_shared<ResultSet>(res);
            default : {
                throw std::runtime_error("sql error. " + get_error_message());    
            }
        }
    }

    // TODO 共通化
    // @see postgresql/src/interfaces/libpq/fe-lobj.c
    // template<typename T>
    // void call_fn(OID oid_fn, T &ret) {
    //     PQArgBlock	argv[2];
	//     PGresult   *res;
    // }

    void begin(const std::string& txid = "default") {
        execute("BEGIN");
        _txid = txid;
    }

    void commit() {
        execute("COMMIT");
        _txid.clear();
    }

    void prepare_tx() {
        execute("PREPARE TRANSACTION '" + _txid + "'");
    }

    void commit_prepared() {
        execute("COMMIT PREPARED '" + _txid + "'");
        _txid.clear();
    }

    void rollback() {
        if (_txid.empty()) {
            return;
        }
        execute("ROLLBACK");
        _txid.clear();
    }

    void rollback_prepared() {
        if (_txid.empty()) {
            return;
        }
        execute("ROLLBACK PREPARED '" + _txid + "'");
        _txid.clear();
    }

    PGconn* get_raw() {
        return _raw.get();
    }

    std::string get_error_message() {
        return std::string(PQerrorMessage(_raw.get()));
    }
private :
    std::string _txid;
    PGconnPtr _raw;
    
};
