#!/bin/bash

set -eu

SCRIPT_DIR=$(cd $(dirname $0); pwd)

MOD_NAME=lo_extends
SRC=${MOD_NAME}.cpp
OBJ=${MOD_NAME}.o
SO_NAME=lib${MOD_NAME}.so
PGSQL_DIR=/usr/pgsql-9.6

# clean
psql -U postgres -c "
DROP FUNCTION IF EXISTS add_one (integer);
DROP FUNCTION IF EXISTS lo_write_by_offsets (integer, bytea);
"

rm -f ${OBJ} ${SO_NAME} /tmp/${SO_NAME}

# build
g++ -g -O3 -time -I${PGSQL_DIR}/include -I${PGSQL_DIR}/include/server -fPIC -c ${SRC}
g++ -shared -time -o ${SO_NAME} ${OBJ}

# install
cp -p ${SCRIPT_DIR}/${SO_NAME} /tmp/
chown postgres:postgres /tmp/${SO_NAME}

psql -U postgres -c "
CREATE FUNCTION add_one(integer) RETURNS integer
   AS '/tmp/${SO_NAME}' LANGUAGE C;
CREATE FUNCTION lo_write_by_offsets(integer, bytea) RETURNS integer
   AS '/tmp/${SO_NAME}' LANGUAGE C;
"

# test 
psql -U postgres -c "
SELECT add_one(10);
SELECT add_one(2);
"