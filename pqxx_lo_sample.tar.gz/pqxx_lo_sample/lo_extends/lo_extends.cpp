#ifdef __cplusplus
extern "C" {
#endif

// Cヘッダ類はextern Cの中に含めること。
#include "postgres.h"			/* general Postgres declarations */
//#include "commands/trigger.h"
//#include "executor/spi.h"
#include "libpq/be-fsstubs.h"
//#include "utils/rel.h"

PG_MODULE_MAGIC;

PG_FUNCTION_INFO_V1(add_one);
Datum add_one(PG_FUNCTION_ARGS);

PG_FUNCTION_INFO_V1(lo_set_offsets);
Datum lo_set_offsets(PG_FUNCTION_ARGS);

PG_FUNCTION_INFO_V1(lo_write_by_offsets);
Datum lo_write_by_offsets(PG_FUNCTION_ARGS);

PG_FUNCTION_INFO_V1(lo_read_by_offsets);
Datum lo_read_by_offsets(PG_FUNCTION_ARGS);



#ifdef __cplusplus
}
#endif

static int counter = 0;

// TODO oidをとるSQL
//select proname, oid from pg_catalog.pg_proc where proname like 'add%';
#include <vector>
Datum
add_one(PG_FUNCTION_ARGS)
{
	std::vector<uint64_t> v;
	static_cast<void>(v);

	int32		arg = PG_GETARG_INT32(0);
	counter += arg;
	PG_RETURN_INT32(counter);
}

// src/backend/libpq/be-fsstubs.c

Datum
lo_write_by_offsets(PG_FUNCTION_ARGS) 
{
	int32		fd = PG_GETARG_INT32(0);
	bytea	   *wbuf = PG_GETARG_BYTEA_P(1);
	int			bytestowrite;
	int			totalwritten;

	bytestowrite = VARSIZE(wbuf) - VARHDRSZ;
	printf("lo_write_by_offsets. total byte size : %d", bytestowrite);
	// TODO なぜかネットワーク越しで繰り返すより遅い・・・
	// size_t cnt = bytestowrite / 8;
	// for (size_t i = 0; i < cnt; ++i) {
	// 	totalwritten += lo_write(fd, VARDATA(wbuf) + i * 8, 8);
	// }
	totalwritten = lo_write(fd, VARDATA(wbuf), bytestowrite);
	PG_RETURN_INT32(totalwritten);
}

Datum
lo_read_by_offsets(PG_FUNCTION_ARGS)
{
	int32		fd = PG_GETARG_INT32(0);
	int32		len = PG_GETARG_INT32(1);
	bytea	   *retval;
	int			totalread;

	if (len < 0)
		len = 0;

	retval = (bytea *) palloc(VARHDRSZ + len);
	totalread = lo_read(fd, VARDATA(retval), len);
	SET_VARSIZE(retval, totalread + VARHDRSZ);

	PG_RETURN_BYTEA_P(retval);
}

