#pragma once
#include <mutex>
#include "Connecter.h"

using LOID = int64_t;

class LargeObject;
class LargeObjectManager {
public :
    LargeObjectManager(std::shared_ptr<Connecter> conn) : _conn(conn) {
        load_fn_oids();
    };

    virtual ~LargeObjectManager() = default;

    LOID create() {
        auto loid = lo_creat(_conn->get_raw(), INV_READ | INV_WRITE);
        handle_error(loid);
        return loid;
    }

    void remove(LOID loid) {
        handle_error(
            lo_unlink(_conn->get_raw(), loid)
        );
    }

    std::shared_ptr<LargeObject> open_lo(LOID loid) {
        return std::make_shared<LargeObject>(_conn, loid);
    }

    void set_offsets(const size_t *offsets, size_t size) {
        // TODO
    }

    // sample.
    int add_one(int v) {
        int argn = 1;
        PQArgBlock	argv[argn];
        int         result_is_int = 1;
        int			result_len;
        int			retval;
        argv[0].isint = 1;
        argv[0].len = 4;
        argv[0].u.integer = v;
        ResultSet rs(
            PQfn(_conn->get_raw(), oid_fn_add_one,
			   &retval, &result_len, result_is_int, argv, argn)
        );

        if (rs.is_error()) {
            throw std::runtime_error(_conn->get_error_message());
        }
        return retval;
    }
    static OID oid_fn_lo_write_by_offsets;
    static OID oid_fn_add_one;
private :
    std::shared_ptr<Connecter> _conn;
    void handle_error(int rc) {
        if (rc <= 0) {
            throw std::runtime_error(_conn->get_error_message());
        }
    }
    // TODO →Connecterに。
    std::mutex _mtx;
    void load_fn_oids() {
        std::unique_lock<decltype(_mtx)> lock(_mtx);
        if (is_init) {
            return;
        }
        static std::vector<std::string> kFnNames = {"add_one"};// TODO 追加する
        auto res = _conn->execute("select proname, oid from pg_catalog.pg_proc where proname in ('add_one','lo_write_by_offsets')");
        const auto record_length = res->get_record_length();
        for (int i = 0; i < record_length; ++i) {
            const auto fname = res->get_value(i, 0);
            if ("add_one" == fname) {
                oid_fn_add_one = res->get_value_as<OID>(i, 1);
                std::cout << "add_one oid : " << oid_fn_add_one << std::endl;
                continue;
            }
            if ("lo_write_by_offsets" == fname) {
                oid_fn_lo_write_by_offsets = res->get_value_as<OID>(i, 1);
                std::cout << "lo_write_by_offsets oid : " << oid_fn_lo_write_by_offsets << std::endl;
                continue;
            }
        }
        if (oid_fn_add_one == 0) {
            throw std::runtime_error("user function add_one's OID not found.");
        }
        if (oid_fn_lo_write_by_offsets == 0) {
            throw std::runtime_error("user function lo_write_by_offsets's OID not found.");
        }

        is_init = true;
    }

    static bool is_init;
};
OID LargeObjectManager::oid_fn_add_one = 0;
OID LargeObjectManager::oid_fn_lo_write_by_offsets = 0;
bool LargeObjectManager::is_init = false;

class LargeObject {
public : 
    LargeObject(std::shared_ptr<Connecter> conn, LOID loid) : 
        _conn(conn),  _fd(lo_open(conn->get_raw(), loid, INV_READ | INV_WRITE)) {
        handle_error(_fd);
    };
    ~LargeObject() {
        try {
            handle_error(
                lo_close(_conn->get_raw(), _fd)
            );
        } catch (const std::exception &e) {
            std::cerr << "large object close failed. cause : " << e.what() << std::endl;
        }
    }

    void read(char *value, size_t len) {
        handle_error(
            lo_read(_conn->get_raw(), _fd, value, len)
        );
    }

    template<typename T>
    void read(T &value) {
        read(reinterpret_cast<char *>(&value), sizeof(T));
    }

    template<typename T>
    void read_all(T *values, size_t len) {
        read(reinterpret_cast<char *>(values), sizeof(T) * len);
    }

    void write(const char *value, size_t len) {
        handle_error(
            lo_write(_conn->get_raw(), _fd, value, len)
        );
    }

    template<typename T>
    void write(const T &value) {
        write(reinterpret_cast<const char *>(&value), sizeof(T));
    }

    template<typename T>
    void write_all(const T *values, size_t len) {
        write(
            reinterpret_cast<const char *>(values), sizeof(T) * len
        );
    }

    void write_by_offsets(const char *value, size_t len, int ofd) {
        // lo_write(_conn->get_raw(), _fd, value, len)
        int argn = 2;
        PQArgBlock	argv[argn];
        int         result_is_int = 1;
        PGresult   *res;
        int			result_len;
        int			retval;

        argv[0].isint = 1;
        argv[0].len = 4;
        argv[0].u.integer = _fd;

        argv[1].isint = 0;
        argv[1].len = static_cast<int>(len);
        argv[1].u.ptr = (int *)value;

        ResultSet rs(
            PQfn(_conn->get_raw(), LargeObjectManager::oid_fn_lo_write_by_offsets,
                &retval, &result_len, result_is_int, argv, argn)
        );

        if (rs.is_error()) {
            throw std::runtime_error(_conn->get_error_message());
        }

    }   
    template<typename T>
    void write_by_offsets(const T *values, size_t len, int ofd) {
        write_by_offsets(
            reinterpret_cast<const char *>(values), sizeof(T) * len, ofd
        );
    } 

    void skip(size_t offset) {
        handle_error(
            lo_lseek64(_conn->get_raw(), _fd, offset, SEEK_CUR)
        );
    }

    template<typename T>
    void skip(size_t size = 1) {
        skip(sizeof(T) * size);
    }

    void seek(size_t offset) {
        handle_error(
            lo_lseek64(_conn->get_raw(), _fd, offset, SEEK_SET)
        );
    }

    template<typename T>
    void seek(size_t size = 1) {
        seek(sizeof(T) * size);
    }

    size_t tell() {
        auto pos = lo_tell64(_conn->get_raw(), _fd);
        handle_error(pos);
        return pos;
    }

    void truncate(size_t len) {
        handle_error(
            lo_truncate64(_conn->get_raw(), _fd, len)
        );
    }
    
private :
    std::shared_ptr<Connecter> _conn;
    const int _fd;
    void handle_error(int rc) {
        if (rc < 0) {
            throw std::runtime_error(std::string(PQerrorMessage(_conn->get_raw())));
        }
    }

};
