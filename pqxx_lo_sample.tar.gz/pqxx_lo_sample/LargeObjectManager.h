#pragma once
#include "Connecter.h"

using LOID = int64_t;

class LargeObject;
class LargeObjectManager {
public :
    LargeObjectManager(std::shared_ptr<Connecter> conn) : _conn(conn) {
    };

    virtual ~LargeObjectManager() = default;

    LOID create() {
        auto loid = lo_creat(_conn->get_raw(), INV_READ | INV_WRITE);
        handle_error(loid);
        return loid;
    }

    void remove(LOID loid) {
        handle_error(
            lo_unlink(_conn->get_raw(), loid)
        );
    }

    std::shared_ptr<LargeObject> open_lo(LOID loid) {
        return std::make_shared<LargeObject>(_conn, loid);
    }

    void set_offsets(const size_t *offsets, size_t size) {
        // TODO
    }

    // sample.
    int add_one(int v) {
        int argn = 1;
        PQArgBlock	argv[argn];
        int         result_is_int = 1;
        int			result_len;
        int			retval;
        argv[0].isint = 1;
        argv[0].len = 4;
        argv[0].u.integer = v;
        ResultSet rs(
            PQfn(_conn->get_raw(), _conn->get_fn_oid("add_one"),
			   &retval, &result_len, result_is_int, argv, argn)
        );

        if (rs.is_error()) {
            throw std::runtime_error(_conn->get_error_message());
        }
        return retval;
    }
private :
    std::shared_ptr<Connecter> _conn;
    void handle_error(int64_t rc) {
        if (rc <= 0) {
            throw std::runtime_error(_conn->get_error_message());
        }
    }
};

class LargeObject {
public : 
    LargeObject(std::shared_ptr<Connecter> conn, LOID loid) : 
        _conn(conn),  _fd(lo_open(conn->get_raw(), loid, INV_READ | INV_WRITE)) {
        handle_error(_fd);
    };
    ~LargeObject() {
        try {
            handle_error(
                lo_close(_conn->get_raw(), _fd)
            );
        } catch (const std::exception &e) {
            std::cerr << "large object close failed. cause : " << e.what() << std::endl;
        }
    }

    void read(char *value, size_t len) {
        handle_error(
            lo_read(_conn->get_raw(), _fd, value, len)
        );
    }

    template<typename T>
    void read(T &value) {
        read(reinterpret_cast<char *>(&value), sizeof(T));
    }

    template<typename T>
    void read_all(T *values, size_t len) {
        read(reinterpret_cast<char *>(values), sizeof(T) * len);
    }

    void write(const char *value, size_t len) {
        handle_error(
            lo_write(_conn->get_raw(), _fd, value, len)
        );
    }

    template<typename T>
    void write(const T &value) {
        write(reinterpret_cast<const char *>(&value), sizeof(T));
    }

    template<typename T>
    void write_all(const T *values, size_t len) {
        write(
            reinterpret_cast<const char *>(values), sizeof(T) * len
        );
    }

    void write_by_offsets(const char *value, size_t len, int ofd) {
        // lo_write(_conn->get_raw(), _fd, value, len)
        int argn = 2;
        PQArgBlock	argv[argn];
        int         result_is_int = 1;
        PGresult   *res;
        int			result_len;
        int			retval;

        argv[0].isint = 1;
        argv[0].len = 4;
        argv[0].u.integer = _fd;

        argv[1].isint = 0;
        argv[1].len = static_cast<int>(len);
        argv[1].u.ptr = (int *)value;

        ResultSet rs(
            PQfn(_conn->get_raw(), _conn->get_fn_oid("lo_write_by_offsets"),
                &retval, &result_len, result_is_int, argv, argn)
        );

        if (rs.is_error()) {
            throw std::runtime_error(_conn->get_error_message());
        }

    }   
    template<typename T>
    void write_by_offsets(const T *values, size_t len, int ofd) {
        write_by_offsets(
            reinterpret_cast<const char *>(values), sizeof(T) * len, ofd
        );
    } 

    void skip(size_t offset) {
        handle_error(
            lo_lseek64(_conn->get_raw(), _fd, offset, SEEK_CUR)
        );
    }

    template<typename T>
    void skip(size_t size = 1) {
        skip(sizeof(T) * size);
    }

    void seek(size_t offset) {
        handle_error(
            lo_lseek64(_conn->get_raw(), _fd, offset, SEEK_SET)
        );
    }

    template<typename T>
    void seek(size_t size = 1) {
        seek(sizeof(T) * size);
    }

    size_t tell() {
        auto pos = lo_tell64(_conn->get_raw(), _fd);
        handle_error(pos);
        return pos;
    }

    void truncate(size_t len) {
        handle_error(
            lo_truncate64(_conn->get_raw(), _fd, len)
        );
    }
    
private :
    std::shared_ptr<Connecter> _conn;
    const int _fd;
    void handle_error(int64_t rc) {
        if (rc < 0) {
            throw std::runtime_error(std::string(PQerrorMessage(_conn->get_raw())));
        }
    }

};
