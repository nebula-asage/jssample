#include <iostream>
#include <algorithm>
#include <chrono>
#include "Connecter.h"
#include "LargeObjectManager.h"

using namespace std::chrono;

namespace {

using time_point = steady_clock::time_point;

class Timer {

public : 
    Timer(const std::string& name) : 
        _name(name), _tp(steady_clock::now()) {
        std::cout << _name << " start." << std::endl;
    }
    ~Timer() {
        std::cout << _name << " end. " << duration_cast<milliseconds>(steady_clock::now() - _tp).count() << "[ms]" << std::endl;
    }

private :
    const std::string _name;
    time_point _tp;
};

} // unnamed namespace

const std::string kConnInfo = "postgresql://postgres@localhost:5432/postgres";
int main() {
    std::cout << "Hello world!" << std::endl;
    auto conn = std::make_shared<Connecter>(kConnInfo);
    auto manager = std::make_shared<LargeObjectManager>(conn);
    try {
        conn->begin();
    } catch(...) {
        std::cerr << "begin error." << std::endl;
        return 1;
    }
    try {
        // conn->execute("insert into foo (name) values (NULL)");
        auto inv_oid = manager->create(); //lo_creat(raw, INV_READ | INV_WRITE);
        // auto inv_oid = 16416;
        std::cout << "oid : " << inv_oid << std::endl;
        size_t size = 10000;
        std::vector<uint64_t> v(size);
        std::iota(v.begin(), v.end(), 0);
        {
            conn->execute("create table tmp(id bigint)");
        }
        {
            conn->execute("drop table tmp");
        }
        {
            auto res = conn->execute("select 1111");
            std::cout << res->get_value_as<uint64_t>(0, 0) << std::endl;
        }
        {
            Timer t("write01");
            auto lo = manager->open_lo(inv_oid);
            for (auto i = 0U; i < size; ++i) {
                // if (i % 2 == 0) {
                //     lo->skip<decltype(v)::value_type>();
                //     continue;
                // }
                lo->write(v[i]);
            }
        }
        {
            Timer t("write02");
            auto lo = manager->open_lo(inv_oid);
            // lo->write_all(v.data(), v.size());
            lo->write_by_offsets(v.data(), v.size(), 0);
        }

        {
            Timer t("read01");
            auto lo = manager->open_lo(inv_oid);
            for (auto i = 0U; i < size; ++i) {
                decltype(v)::value_type d;
                lo->read(d);
                // std::cout << "i : " << i << ", value : " << d << std::endl;
            }
        }
        {
            Timer t("read02");
            auto lo = manager->open_lo(inv_oid);
            std::vector<uint64_t> vc(size);
            lo->read_all(vc.data(), vc.size());
        }
        {
            std::cout << "add one 1 : " << manager->add_one(10) << std::endl;
            std::cout << "add one 2 : " << manager->add_one(10) << std::endl;
        }

        manager->remove(inv_oid);
        conn->prepare_tx();
    } catch (const std::exception& e) {
        std::cerr << "1st phase error. " << e.what() << std::endl;
        conn->rollback();
        return 1;
    }
    
    try {
        conn->commit_prepared();
    } catch(const std::exception& e) {
        std::cerr << "2nd phase error. " << e.what() << std::endl;
        conn->rollback_prepared();
        return 1;
    }
}