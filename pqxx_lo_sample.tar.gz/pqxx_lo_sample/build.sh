#!/bin/bash

PGSQL_DIR=/usr/pgsql-9.6

# clean
rm -rf *.dSYM main

# build
g++ -g -time -std=c++11 -O0 \
    -I${PGSQL_DIR}/include \
    -L${PGSQL_DIR}/lib \
    -lpq main.cpp -o main