

function inherits(targetClazz, BaseClazz) {
    Object.setPrototypeOf(targetClazz.prototype, BaseClazz.prototype);
}
var mergeObject = function (target, arg) {
    return $.extend(target, arg);
};

var copyObject = function (target) {
    return JSON.parse(JSON.stringify(target));
};

var constraint = function (name, constraint) {
    var valid = {
        isValid: true,
        message: ""
    };
    try {
        constraint();
        return valid;
    } catch (e) {
        valid.isValid = false;
        valid.message = e.message;
        return valid;
    }
};

var Screen = function (id) {
    this.id = id;
    this.jq = $("#" + id);
    this.vm = null;
};
Screen.prototype.initialize = function () {
};